using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
public class UpdateUI : MonoBehaviour
{
    public Sprite Num0;
    public Sprite Num1;
    public Sprite Num2;
    public Sprite Num3;
    public Sprite Num4;
    public Sprite Num5;

    private Image image;

    PuzzleField pf;

    int SetAddCount;

    bool IsParam;   //�p�����[�^�[��ʂ��ǂ���

    bool pushButton = false;  //�{�^���������ꂽ���ǂ���

    float timer;

    // Start is called before the first frame update
    void Start()
    {
        image = GetComponent<Image>();
       
        SetAddCount = 5;
        timer = 3.0f;
    }

    // Update is called once per frame
    void Update()
    {
        GameObject PF = GameObject.Find("Main Camera");
        pf = PF.GetComponent<PuzzleField>();
        IsParam = pf.IndicationParam;


        if (IsParam == false)
        {
            if (pf.bModeMove == true)
            {
                if (Input.GetKeyDown("joystick button 0") || Input.GetKeyDown(KeyCode.S))
                {
                    SetAddCount--;
                    pf.bModeMove = false;
                }
            }

            if(pf.GetBornus == true)
            {
                SetAddCount++;
                pf.GetBornus = false;
            }
        }

        switch (SetAddCount)
        {
            case 5:
                image.sprite = Num5;
                break;
            case 4:
                image.sprite = Num4;
                break;
            case 3:
                image.sprite = Num3;
                break;
            case 2:
                image.sprite = Num2;
                break;
            case 1:
                image.sprite = Num1;
                break;
            case 0:
                image.sprite = Num0;
                break;
        }

    }
}
