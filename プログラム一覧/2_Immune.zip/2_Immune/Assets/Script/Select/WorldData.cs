using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "WorldData", menuName = "SelectScreen/WorldData")]
public class WorldData : ScriptableObject
{
    public string worldname;
    public int worldnum;
    public StageData[] stages = new StageData[5]; // 5�̃X�e�[�W��ێ�  
}
