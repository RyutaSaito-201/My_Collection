using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class StageData
{
    public string stageName;
    public bool isUnlocked;
    public bool isCleared;
    public Vector3 iconPosition;
    public Vector3 iconScale;

}
