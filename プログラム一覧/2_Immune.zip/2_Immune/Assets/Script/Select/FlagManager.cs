using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlagManager : MonoBehaviour
{
    //public bool WorldSelect = false;
    public bool StageSelect = false;
    //public MonoBehaviour WorldSelectManager;
    public MonoBehaviour StageSelectManager;

    // Update is called once per frame
    void Update()
    {
        if (StageSelect && !StageSelectManager.enabled)
        {
            StageSelectManager.enabled = true;
        }
        else if (!StageSelect && StageSelectManager.enabled)
        {
            StageSelectManager.enabled = false;
        }


    }
}
