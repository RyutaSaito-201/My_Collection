using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Bubble : MonoBehaviour
{
    public GameObject bubblePrefab; // 3D�I�u�W�F�N�g�iCube�j�̃v���n�u
    public int bubbleCountX = 5; // X�������̖A�̐�
    public int bubbleCountY = 6; // Y�������̖A�̐�
    public float bubbleSpeed = 9.0f; // Bubble�̈ړ����x
    public float fadeDuration = 3.0f; // �t�F�[�h�A�E�g�̎���
    public Vector2 spawnRangeX; // Bubble�̐����ʒu��X�͈�
    public Vector2 spawnRangeY; // Bubble�̐����ʒu��Y�͈�
    public float floatAmplitudeMin = 0.6f; // �㉺�^���̍ŏ���
    public float floatAmplitudeMax = 1.0f; // �㉺�^���̍ő啝
    public float floatFrequencyMin = 3.5f; // �㉺�^���̍ŏ�����
    public float floatFrequencyMax = 4.5f; // �㉺�^���̍ő呬��

    private List<GameObject> bubbles = new List<GameObject>();

    private List<float> randomAmplitudes = new List<float>(); // �e�A�̐U��
    private List<float> randomFrequencies = new List<float>(); // �e�A�̎��g��
    private List<float> randomPhaseOffsets = new List<float>(); // �e�A�̈ʑ��I�t�Z�b�g

    void Start()
    {
        // ���̃X�N���v�g����Ăяo�����߁A�����ł͌Ăяo���܂���
    }

    void CreateBubbles()
    {
        for (int i = 0; i < 50; i++)
        {
            float xPosition = -7;
            float yPosition = (i % 10) - 6;
            float zPosition = -1.0f;
            // �����ʒu
            if (i < 15)
            {
                int j = i % 2;
                if (j == 0)
                {
                    xPosition = -7.0f;
                }
                else
                {
                    if (i == 3 || i == 7 || i == 11)
                    {
                        xPosition = -5.5f;
                    }
                    else
                    {
                        xPosition = -6.25f;
                    }
                }
                yPosition = (6 / 15) * i + (i * 0.5f) - 6.5f;
            }
            else if (i < 30)
            {
                int j = i % 2;
                if (j == 0)
                {
                    xPosition = -8.5f;
                }
                else
                {
                    xPosition = -10.0f;
                }
                yPosition = (6 / 15) * (i - 19) + ((i - 19) * 1.0f) - 6.5f;
            }
            else if (i < 40)
            {
                int j = i % 2;
                if (j == 0)
                {
                    xPosition = -14;
                }
                else
                {
                    xPosition = -12;
                }
                yPosition = (6 / 10) * (i - 29) + ((i - 29) * 1.25f) - 10.0f;
            }
            else
            {
                int j = i % 2;
                if (j == 0)
                {
                    xPosition = -18;
                }
                else
                {
                    xPosition = -24;
                }
                yPosition = (6 / 10) * (i - 39) + ((i - 39) * 1.0f) - 10.0f;
            }

            Vector3 spawnPosition = new Vector3(xPosition, yPosition, zPosition);

            GameObject bubble = Instantiate(bubblePrefab, spawnPosition, Quaternion.identity);
            if (i < 15)
            {
                bubble.transform.localScale = Vector3.one * 1.0f; // �����T�C�Y��ݒ�
            }
            else if (i < 30)
            {
                bubble.transform.localScale = Vector3.one * 2.0f; // �����T�C�Y��ݒ�
            }
            else if (i < 40)
            {
                bubble.transform.localScale = Vector3.one * 3.0f; // �����T�C�Y��ݒ�
            }
            else
            {
                bubble.transform.localScale = Vector3.one * 8.0f; // �����T�C�Y��ݒ�
            }
            bubbles.Add(bubble);

            // �����_���ȐU���A���g���A�ʑ��I�t�Z�b�g��ǉ�
            randomAmplitudes.Add(Random.Range(floatAmplitudeMin, floatAmplitudeMax));
            randomFrequencies.Add(Random.Range(floatFrequencyMin, floatFrequencyMax));
            randomPhaseOffsets.Add(Random.Range(0f, Mathf.PI * 2f)); // 0����2�΂܂ł̃����_���Ȉʑ�

            StartCoroutine(MoveAndFadeBubble(bubble, i));
        }
    }

    IEnumerator MoveAndFadeBubble(GameObject bubble, int index)
    {
        Renderer bubbleRenderer = bubble.GetComponent<Renderer>();
        float elapsedTime = 0f;
        Vector3 initialPosition = bubble.transform.position; // �����ʒu��ێ�

        float randomAmplitude = randomAmplitudes[index];
        float randomFrequency = randomFrequencies[index];
        float randomPhaseOffset = randomPhaseOffsets[index];

        while (elapsedTime < fadeDuration)
        {
            // �ړ�
            bubble.transform.Translate(Vector3.right * bubbleSpeed * Time.deltaTime);

            // �s�K����Y���̏㉺�^���i�ӂ�ӂ�j
            float newY = initialPosition.y + Mathf.Sin(Time.time * randomFrequency + randomPhaseOffset) * randomAmplitude;
            bubble.transform.position = new Vector3(bubble.transform.position.x, newY, bubble.transform.position.z);

            // �t�F�[�h�A�E�g
            float alpha = Mathf.Min(1f, elapsedTime / fadeDuration);
            Color newColor = bubbleRenderer.material.color;
            newColor.a = alpha;
            bubbleRenderer.material.color = newColor;

            elapsedTime += Time.deltaTime;
            yield return null;
        }
    }

    // ���̃X�N���v�g����Ăяo���֐�
    public void StartBubbleTransition()
    {
        CreateBubbles();
    }
}
