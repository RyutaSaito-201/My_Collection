using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

[DefaultExecutionOrder(-10000)]
public class CountUI : MonoBehaviour
{
    public GameObject WallObj;
    //public GameObject Count_Text; // Text�I�u�W�F�N�g
    //public GameObject Puzzle_Text;
    [SerializeField] private int score_index = 5;
    [SerializeField] private int puzzle_No = 3;

    const int debug = 0;
    // ������
    void Start()
    {
#if debug
        GameObject a;
        a = Instantiate(WallObj,
                   new Vector3(550.5f, 255f, 0.0f),
                    Quaternion.identity);

        foreach(Transform b in WallObj.transform)
            {
            a = b;
        }
#endif
        // �I�u�W�F�N�g����Text�R���|�[�l���g���擾
        //TMP_Text score = Count_Text.GetComponent<TMP_Text>();
        //TMP_Text PuzzleNo = Puzzle_Text.GetComponent<TMP_Text>();
        // �e�L�X�g�̕\�������ւ���

        string sscore = score_index.ToString();
        string sPuzzle = puzzle_No.ToString();

        //score.text = "Round " + sscore + " / 5";
        //PuzzleNo.text = "Remaining count : " + sPuzzle;



    }

    // �X�V
    void Update()
    {
        //TMP_Text score = Count_Text.GetComponent<TMP_Text>();
        
        if (Input.GetKeyDown(KeyCode.C))
        {
            if (score_index != 5)
            {
                score_index++;

                //string sscore = "Round " + score_index.ToString() + " / 5";
                //score.text = sscore;
            }
        }

       

    }
    public void ChangePizzleNo()
    {
        //TMP_Text PuzzleNo = Puzzle_Text.GetComponent<TMP_Text>();
        Debug.Log("1");
        if (puzzle_No != 0)
        {
            puzzle_No--;

            //string sPuzzle = "Remaining count : " + puzzle_No.ToString();
            //PuzzleNo.text = sPuzzle;
        }
    }

    public void AddPuzzleNo(int add)
    {
        puzzle_No += add;
    }

    public bool ReturnCreate()
    {
        if(puzzle_No != 0)
        {
            return true;
        }
        else
        {
            //SceneManager.LoadScene("BattleScene");
            return false;
        }
        
    }
}
