using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InitUI : MonoBehaviour
{
    // Start is called before the first frame update

    // �萔��`
    const float TOTAL_MOVE_TIME = 0.4f;    // �l�N�X�g�A�C�R���̃R���[�`���̎���
    const float CURSOR_MIN_X = -144.0f;    // �J�[�\���𓮂�����͈�
    const float CURSOR_MAX_X = 142.0f;
    const float CURSOR_MIN_Y = -203.0f;
    const float CURSOR_MAX_Y = 76.0f;

    const float ROUND_POS_X = 343.0f;
    const float ROUND_POS_Y = 189.0f;

    //�G�Ֆʂ̒萔��`
    const float ENEMY_X_1 = 6.4f;
    const float ENEMY_X_2 = 6.85f;
    const float ENEMY_X_3 = 7.3f;
    const float ENEMY_X_4 = 7.75f;
    const float ENEMY_X_5 = 8.2f;

    const float ENEMY_Y_1 = -3.05f;
    const float ENEMY_Y_2 = -2.61f;
    const float ENEMY_Y_3 = -2.17f;
    const float ENEMY_Y_4 = -1.73f;
    const float ENEMY_Y_5 = -1.29f;

    PuzzleField pf;

    //�p�Y���V�[���Ŏg���Ă���L�����o�X
    public CanvasGroup puzzle;
    public CanvasGroup param;
    public CanvasGroup field;

    //---�V�[���Ŏg���Ă���I�u�W�F�N�g---
    // �p�Y��
    public GameObject rightArrow;  //�E���
    public GameObject leftArrow;   //�����
    public GameObject nextBase;    //���o�ė��钇��
    public GameObject nextLeftIcon;     // ���ɏo�Ă��钇�ԃA�C�R��(��)
    public GameObject nextRightIcon;    //           �V          (�E)
    public GameObject nextLeftIcon2;    // ���̎��ɏo�Ă��钇�ԃA�C�R��(��)
    public GameObject nextRightIcon2;   //             �V           (�E)
    public GameObject nextLeftIcon3;    // ���̎��̎��ɏo�Ă��钇�ԃA�C�R��(��)
    public GameObject nextRightIcon3;   //               �V             (�E)
    public GameObject explan;      //�������
    public GameObject AddFollower; //���₹�钇�Ԃ̉�

    // �p�����[�^
    public GameObject ParamRadar;  //�p�����[�^�̃��[�_�[�`���[�gUI
    public GameObject RangeBack;   //�U���͈͂̔w�i�摜
    public GameObject Cursor;      // �J�[�\��
    public GameObject ParamF01;    // �t�@�C�^�[01�̃p�����[�^
    public GameObject ParamF02;    // �t�@�C�^�[02�̃p�����[�^
    public GameObject ParamF03;    // �t�@�C�^�[03�̃p�����[�^
    public GameObject ParamF04;    // �t�@�C�^�[04�̃p�����[�^
    public GameObject ParamF05;    // �t�@�C�^�[05�̃p�����[�^
    public GameObject ParamA01;    // �A�[�`���[01�̃p�����[�^
    public GameObject ParamA02;    // �A�[�`���[02�̃p�����[�^
    public GameObject ParamA03;    // �A�[�`���[03�̃p�����[�^
    public GameObject ParamA04;    // �A�[�`���[04�̃p�����[�^
    public GameObject ParamA05;    // �A�[�`���[05�̃p�����[�^
    public GameObject ParamH01;    // �q�[���[01�̃p�����[�^
    public GameObject ParamH02;    // �q�[���[02�̃p�����[�^
    public GameObject ParamH03;    // �q�[���[03�̃p�����[�^
    public GameObject ParamH04;    // �q�[���[04�̃p�����[�^
    public GameObject ParamH05;    // �q�[���[05�̃p�����[�^
    public GameObject ParamFA;     // �t�@�C�^�[�ƃA�[�`���[�̋�p�����[�^
    public GameObject ParamH;      // �q�[���[�̋�p�����[�^

    // �Ֆ�
    public GameObject Field;       //�p�Y���Ֆʕ\��
    public GameObject RoundBase;   //���E���h���
    public GameObject EnemyBoard; //�G�Ֆ�


    //���E���h��
    public GameObject Round1;   //���E���hUI 1.2.3.4.5
    public GameObject Round2;
    public GameObject Round3;
    public GameObject Round4;
    public GameObject Round5;

    // �����A�C�R��
    public GameObject FighterIcon;  // �t�@�C�^�[�A�C�R��
    public GameObject ArcherIcon;   // �A�[�`���[
    public GameObject HealerIcon;   // �q�[���[

    //�G�A�C�R��
    public GameObject EnemyIcon1; //�G�A�C�R��1
    public GameObject EnemyIcon2; //�G�A�C�R��2
    public GameObject EnemyIcon3; //�G�A�C�R��3
    public GameObject EnemyIcon4; //�G�A�C�R��4
    public GameObject EnemyIcon5; //�G�A�C�R��5
    public GameObject EnemyIcon6; //�G�A�C�R��6
    public GameObject EnemyIcon7; //�G�A�C�R��7
    public GameObject EnemyIcon8; //�G�A�C�R��8
    public GameObject BossIcon;   //�{�X�A�C�R��

    //���₹��񐔂̐���
    public GameObject Add5;

    
    GameObject Num;

    // �l�N�X�g�L�����A�C�R���֘A
    public bool isFirst = true;

    // �X�e�[�^�X�֘A
    int oldKind = 0;    // �J�[�\�����ǂ̃L�������w���Ă������̑ޔ�p

    //�w�i
    public GameObject BackGround;

    PuzzleField puzzleField;

    int SetAddCount;
    int RoundCount;

    int StageCount;

    private float prevHorizontalInput = 0; //�O�̃t���[���̐������͒l��ێ�����ϐ�

    void Start()
    {
        pf = GetComponent<PuzzleField>();

        //puzzleField = gameObject.AddComponent<PuzzleField>();
        //SetAddCount = puzzleField.GetPuzzleNum();

        RoundCount = PuzzleField.Round;

        StageCount = CharaManager.Stage;

        //�w�i
        Instantiate(BackGround, new Vector3(3.0f, -2.5f, 0.0f), Quaternion.identity);

        // New Sprite�v���n�u�����ɁA�C���X�^���X�𐶐�

        //=====�p�Y�����UI====
        //----���----
        leftArrow = Instantiate(leftArrow, new Vector3(-65.0f, 190.0f, 0.0f), Quaternion.identity); //�������A�����ʒu�A��]�d�l
        leftArrow.transform.SetParent(puzzle.transform, false);

        rightArrow = Instantiate(rightArrow, new Vector3(125.0f, 190.0f, 0.0f), Quaternion.identity);
        rightArrow.transform.SetParent(puzzle.transform, false);

        //----���----
        //�l�N�X�gUI
        nextBase = Instantiate(nextBase, new Vector3(-267.0f, 68.0f, 0.0f), Quaternion.identity);
        nextBase.transform.SetParent(puzzle.transform, false);

        //�L�����ǉ��c���UI
        AddFollower = Instantiate(AddFollower, new Vector3(-270.0f, -138.0f, 0.0f), Quaternion.identity);//-293
        AddFollower.transform.SetParent(puzzle.transform, false);

        //----�������UI----
        explan = Instantiate(explan, new Vector3(280.0f, -145f, 0.0f), Quaternion.identity);
        explan.transform.SetParent(puzzle.transform, false);


        //============================================================================================

        //=====�p�����[�^���UI=====        
        // �U���͈�UI
        RangeBack = Instantiate(RangeBack, new Vector3(-281.0f, -146.0f, 0.0f), Quaternion.identity);
        RangeBack.transform.SetParent(param.transform, false);

        // �J�[�\��
        Cursor = Instantiate(Cursor, new Vector3(0.0f, 0.0f, 0.0f), Quaternion.identity);
        Cursor.transform.SetParent(param.transform, false);
        Cursor.transform.localScale = new Vector3(2.5f, 2.5f, 0.0f);

        // ���[�_�[�`���[�gUI
        ParamRadar = Instantiate(ParamFA, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
        ParamRadar.transform.SetParent(param.transform, false);

        //=============================================================================================

        //=====���ʕ\��(�p�����[�^�A�p�Y�����)��UI=====
        //�Ֆ�UI
        Field = Instantiate(Field, new Vector3(-10.0f, -51.0f, 0.0f), Quaternion.identity);
        Field.transform.SetParent(field.transform, false);

        //���E���h�{�[�hUI
        RoundBase = Instantiate(RoundBase, new Vector3(299.0f, 181.0f, 0.0f), Quaternion.identity);
        RoundBase.transform.SetParent(field.transform, false);

        //�G�Ֆ�UI
        EnemyBoard = Instantiate(EnemyBoard, new Vector3(295.0f, 42.0f, 0.0f), Quaternion.identity);
        EnemyBoard.transform.SetParent(field.transform, false);

        //----���E���h���ɈႤUI(���E���h���A�G�z�u)----
        SetEnemyBoard();

        //���炷��
        Num = Instantiate(Add5, new Vector3(-267f, -138f, 0.0f), Quaternion.identity);
        Num.transform.SetParent(puzzle.transform, false);
        //=============================================================================================


    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(puzzle.alpha);
        GameObject PF = GameObject.Find("Main Camera");
        pf = PF.GetComponent<PuzzleField>();
        if (pf.IndicationParam)
        {
            //Debug.Log("���������`�I�I�I");
            puzzle.alpha = 0;
            param.alpha = 1;
            MoveCursor();
            ViewCharaStatus();
        }
        else
        {
            //�p�Y����ʁA�p�����[�^��ʂ�UI�̃��l��߂�
            if (!pf.PF_canvas)
            {
                puzzle.alpha = 1;
            }
            param.alpha = 0;

            float currentHorizontalInput = Input.GetAxis("Debug Horizontal");

            //A,D����������ړ�
            if (currentHorizontalInput < 0 &&   //�\���L�[
                        prevHorizontalInput >= 0 || Input.GetKeyDown(KeyCode.A))
            {
                if (leftArrow.transform.position.x > 0.5f)
                {
                    //�������E�����ĕ\������
                    rightArrow.GetComponent<CanvasRenderer>().SetAlpha(1);
                    leftArrow.transform.Translate(-1.0f, 0.0f, 0.0f);
                    rightArrow.transform.Translate(-1.0f, 0.0f, 0.0f);
                }
            }
            if (currentHorizontalInput > 0 && //�\���L�[
                        prevHorizontalInput <= 0 || Input.GetKeyDown(KeyCode.D))
            {
                if (rightArrow.transform.position.x < 5.5f)
                {
                    //�������������ĕ\������
                    leftArrow.GetComponent<CanvasRenderer>().SetAlpha(1);
                    leftArrow.transform.Translate(1.0f, 0.0f, 0.0f);
                    rightArrow.transform.Translate(1.0f, 0.0f, 0.0f);
                }
            }
            //�O�̃t���[���̐������͒l�����݂̓��͒l�ōX�V����
            prevHorizontalInput = currentHorizontalInput;

            //��󂪏����锻��
            if (leftArrow.transform.position.x <= 0.5f)
            {
                leftArrow.GetComponent<CanvasRenderer>().SetAlpha(0);
            }
            else if (rightArrow.transform.position.x >= 5.5f)
            {
                rightArrow.GetComponent<CanvasRenderer>().SetAlpha(0);
            }

            //�L��������]�����炻��ɍ��킹�Ė��𓮂���
            switch (pf.RotatePattern)
            {
                case 1:
                    //leftArrow.transform.Translate(-1.0f, 0.0f, 0.0f);
                    rightArrow.transform.Translate(-1.0f, 0.0f, 0.0f);
                    pf.RotatePattern = 0;
                    break;
                case 2:
                    leftArrow.transform.Translate(-1.0f, 0.0f, 0.0f);
                    pf.RotatePattern = 0;
                    break;
                case 3:
                    leftArrow.transform.Translate(1.0f, 0.0f, 0.0f);
                    pf.RotatePattern = 0;
                    break;
                case 4:
                    rightArrow.transform.Translate(1.0f, 0.0f, 0.0f);
                    pf.RotatePattern = 0;
                    break;
            }


            //�������̏ꏊ�ɖ߂�
            if (pf.bModeDrop == true)
            {
                leftArrow.GetComponent<CanvasRenderer>().SetAlpha(1);
                rightArrow.GetComponent<CanvasRenderer>().SetAlpha(1);
                leftArrow.transform.position = new Vector3(2.0f, 0.46f, 0.0f);
                rightArrow.transform.position = new Vector3(5.0f, 0.46f, 0.0f);
                pf.bModeDrop = false;
            }

        }

    }

    void MoveCursor()
    {
        // �O�̍��W��ޔ�
        Vector3 oldPos = new Vector3(Cursor.transform.localPosition.x, Cursor.transform.localPosition.y, 0.0f);

        // �ړ�
        if (Input.GetKey(KeyCode.W)) Cursor.transform.Translate(0.0f, 0.01f, 0.0f);
        if (Input.GetKey(KeyCode.S)) Cursor.transform.Translate(0.0f, -0.01f, 0.0f);
        if (Input.GetKey(KeyCode.A)) Cursor.transform.Translate(-0.01f, 0.0f, 0.0f);
        if (Input.GetKey(KeyCode.D)) Cursor.transform.Translate(0.01f, 0.0f, 0.0f);

        // �␳
        if (Cursor.transform.localPosition.x > CURSOR_MAX_X ||
            Cursor.transform.localPosition.x < CURSOR_MIN_X ||
            Cursor.transform.localPosition.y > CURSOR_MAX_Y ||
            Cursor.transform.localPosition.y < CURSOR_MIN_Y) Cursor.transform.localPosition = oldPos;
    }

    // �L�����X�e�[�^�X�\���֐�
    void ViewCharaStatus()
    {
        // �J�[�\���̏ꏊ�ɂ���L�����̎�ނ��擾
        int kind = pf.GetCharaKind(Cursor.transform.position.x, Cursor.transform.position.y);
        if (oldKind != kind)
        {
            // �O�̃p�����[�^���폜
            DestroyImmediate(param.transform.GetChild(2).gameObject);
            // �摜�\��
            switch (kind)
            {
                case 1:     // �t�@�C�^�[(1~5)
                    ParamRadar = Instantiate(ParamF01, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 2:
                    ParamRadar = Instantiate(ParamF02, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 3:
                    ParamRadar = Instantiate(ParamF03, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 4:
                    ParamRadar = Instantiate(ParamF04, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 5:
                    ParamRadar = Instantiate(ParamF05, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 6:     // �A�[�`���[(6~10)
                    ParamRadar = Instantiate(ParamA01, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 7:
                    ParamRadar = Instantiate(ParamA02, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 8:
                    ParamRadar = Instantiate(ParamA03, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 9:
                    ParamRadar = Instantiate(ParamA04, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 10:
                    ParamRadar = Instantiate(ParamA05, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 11:    // �q�[���[(11~15)
                    ParamRadar = Instantiate(ParamH01, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 12:
                    ParamRadar = Instantiate(ParamH02, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 13:
                    ParamRadar = Instantiate(ParamH03, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 14:
                    ParamRadar = Instantiate(ParamH04, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                case 15:
                    ParamRadar = Instantiate(ParamH05, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
                default:    // �N���w���Ă��Ȃ��ꍇ
                    ParamRadar = Instantiate(ParamFA, new Vector3(-281.0f, 10.0f, 0.0f), Quaternion.identity);
                    break;
            }
            ParamRadar.transform.SetParent(param.transform, false);
        }
        oldKind = kind;     // ���x���\�����Ȃ����߂ɑޔ�
    }

    // �l�N�X�g�A�C�R���\���֐�
    public void NextCharaIcon(
        int leftIcon, int rightIcon, int leftIcon2, int rightIcon2, int leftIcon3, int rightIcon3)     // �l�N�X�g�����A�C�R���\��
    {
        //---���̃A�C�R��---
        // ���A�C�R��
        switch ((leftIcon - 1) % 3 + 1)
        {
            case 1:     // �t�@�C�^�[
                nextLeftIcon = Instantiate(FighterIcon, new Vector3(-267.0f, 134.0f, 0.0f), Quaternion.identity);
                break;
            case 2:     // �A�[�`���[
                nextLeftIcon = Instantiate(ArcherIcon, new Vector3(-267.0f, 134.0f, 0.0f), Quaternion.identity);
                break;
            case 3:     // �q�[���[
                nextLeftIcon = Instantiate(HealerIcon, new Vector3(-267.0f, 134.0f, 0.0f), Quaternion.identity);
                break;
        }
        nextLeftIcon.transform.SetParent(puzzle.transform, false);  // �e��ݒ�
        nextLeftIcon.transform.localScale = new Vector3(25.0f, 12.5f, 0.0f);  // �傫����ύX

        // �E�A�C�R��
        switch ((rightIcon - 1) % 3 + 1)
        {
            case 1:     // �t�@�C�^�[
                nextRightIcon = Instantiate(FighterIcon, new Vector3(-267.0f, 68.0f, 0.0f), Quaternion.identity);
                break;
            case 2:     // �A�[�`���[
                nextRightIcon = Instantiate(ArcherIcon, new Vector3(-267.0f, 68.0f, 0.0f), Quaternion.identity);
                break;
            case 3:     // �q�[���[
                nextRightIcon = Instantiate(HealerIcon, new Vector3(-267.0f, 68.0f, 0.0f), Quaternion.identity);
                break;
        }
        nextRightIcon.transform.SetParent(puzzle.transform, false);
        nextRightIcon.transform.localScale = new Vector3(25.0f, 12.5f, 0.0f);

        //---���̎��̃A�C�R��---
        // ���A�C�R��
        switch ((leftIcon2 - 1) % 3 + 1)
        {
            case 1:     // �t�@�C�^�[
                nextLeftIcon2 = Instantiate(FighterIcon, new Vector3(-267.0f, 2.0f, 0.0f), Quaternion.identity);
                break;
            case 2:     // �A�[�`���[
                nextLeftIcon2 = Instantiate(ArcherIcon, new Vector3(-267.0f, 2.0f, 0.0f), Quaternion.identity);
                break;
            case 3:     // �q�[���[
                nextLeftIcon2 = Instantiate(HealerIcon, new Vector3(-267.0f, 2.0f, 0.0f), Quaternion.identity);
                break;
        }
        nextLeftIcon2.transform.SetParent(puzzle.transform, false);  // �e��ݒ�
        nextLeftIcon2.transform.localScale = new Vector3(15.0f, 7.5f, 0.0f);  // �傫����ύX

        // �E�A�C�R��
        switch ((rightIcon2 - 1) % 3 + 1)
        {
            case 1:     // �t�@�C�^�[
                nextRightIcon2 = Instantiate(FighterIcon, new Vector3(-267.0f, -38.0f, 0.0f), Quaternion.identity);
                break;
            case 2:     // �A�[�`���[
                nextRightIcon2 = Instantiate(ArcherIcon, new Vector3(-267.0f, -38.0f, 0.0f), Quaternion.identity);
                break;
            case 3:     // �q�[���[
                nextRightIcon2 = Instantiate(HealerIcon, new Vector3(-267.0f, -38.0f, 0.0f), Quaternion.identity);
                break;
        }
        nextRightIcon2.transform.SetParent(puzzle.transform, false);
        nextRightIcon2.transform.localScale = new Vector3(15.0f, 7.5f, 0.0f);

        //---���̎��̎��̃A�C�R��---
        // ���A�C�R��
        switch ((leftIcon3 - 1) % 3 + 1)
        {
            case 1:     // �t�@�C�^�[
                nextLeftIcon3 = Instantiate(FighterIcon, new Vector3(-267.0f, 2.0f, 0.0f), Quaternion.identity);
                break;
            case 2:     // �A�[�`���[
                nextLeftIcon3 = Instantiate(ArcherIcon, new Vector3(-267.0f, 2.0f, 0.0f), Quaternion.identity);
                break;
            case 3:     // �q�[���[
                nextLeftIcon3 = Instantiate(HealerIcon, new Vector3(-267.0f, 2.0f, 0.0f), Quaternion.identity);
                break;
        }
        nextLeftIcon3.transform.SetParent(puzzle.transform, false);  // �e��ݒ�
        nextLeftIcon3.transform.localScale = new Vector3(0.0f, 0.0f, 0.0f);  // �傫����ύX

        // �E�A�C�R��
        switch ((rightIcon3 - 1) % 3 + 1)
        {
            case 1:     // �t�@�C�^�[
                nextRightIcon3 = Instantiate(FighterIcon, new Vector3(-267.0f, -38.0f, 0.0f), Quaternion.identity);
                break;
            case 2:     // �A�[�`���[
                nextRightIcon3 = Instantiate(ArcherIcon, new Vector3(-267.0f, -38.0f, 0.0f), Quaternion.identity);
                break;
            case 3:     // �q�[���[
                nextRightIcon3 = Instantiate(HealerIcon, new Vector3(-267.0f, -38.0f, 0.0f), Quaternion.identity);
                break;
        }
        nextRightIcon3.transform.SetParent(puzzle.transform, false);
        nextRightIcon3.transform.localScale = new Vector3(0.0f, 0.0f, 0.0f);
    }

    // �A�C�R���ړ��R���[�`��
    public IEnumerator MoveIcon1()
    {
        float elapsedTime = 0.0f;   // �o�ߎ���
        bool bMoveIcon2 = false;
        bool bMoveIcon3 = false;
        while (elapsedTime < TOTAL_MOVE_TIME)  // ���v����
        {
            // ���A�C�R���̃R���[�`���ֈڍs
            if (elapsedTime > 0.1f && !bMoveIcon2)
            {
                StartCoroutine(MoveIcon2());
                bMoveIcon2 = true;
            }
            if (elapsedTime > 0.2f && !bMoveIcon3)
            {
                StartCoroutine(MoveIcon3());
                bMoveIcon3 = true;
            }

            // �J�ڂ̐ݒ�
            float t = elapsedTime / TOTAL_MOVE_TIME;
            float ScaleX1 = Mathf.Lerp(25.0f, 0.0f, t);     // ���A�C�R���̉��̊g�k
            float ScaleY1 = Mathf.Lerp(12.5f, 0.0f, t);     // ���A�C�R���̏c�̊g�k

            // �g�k
            nextLeftIcon.transform.localScale = new Vector3(ScaleX1, ScaleY1, 0.0f);
            nextRightIcon.transform.localScale = new Vector3(ScaleX1, ScaleY1, 0.0f);

            // �^�C���X�V
            elapsedTime += Time.deltaTime;
            yield return null; // 1�t���[���ҋ@
        }

        // �ŏI�␳
        nextLeftIcon.transform.localScale = new Vector3(0.0f, 0.0f, 0.0f);
        nextRightIcon.transform.localScale = new Vector3(0.0f, 0.0f, 0.0f);
    }

    public IEnumerator MoveIcon2()
    {
        float elapsedTime = 0.0f;   // �o�ߎ���
        while (elapsedTime < TOTAL_MOVE_TIME)  // ���v����
        {
            // �J�ڂ̐ݒ�
            float t = elapsedTime / TOTAL_MOVE_TIME;
            float ScaleX2 = Mathf.Lerp(15.0f, 25.0f, t);    // ���X�A�C�R���̉��̊g�k
            float ScaleY2 = Mathf.Lerp(7.5f, 12.5f, t);     // ���X�A�C�R���̏c�̊g�k
            float LPos = Mathf.Lerp(-2.965f, -0.92f, t);    // ���X���A�C�R���̍��W
            float RPos = Mathf.Lerp(-3.59f, -1.95f, t);     // ���X�E�A�C�R���̍��W

            // �g�k
            nextLeftIcon2.transform.localScale = new Vector3(ScaleX2, ScaleY2, 0.0f);
            nextRightIcon2.transform.localScale = new Vector3(ScaleX2, ScaleY2, 0.0f);

            // ���W
            nextLeftIcon2.transform.position = new Vector3(-1.15f, LPos, 0.0f);
            nextRightIcon2.transform.position = new Vector3(-1.15f, RPos, 0.0f);

            // �^�C���X�V
            elapsedTime += Time.deltaTime;
            yield return null; // 1�t���[���ҋ@
        }

        //---�ŏI�␳---
        // ���W
        nextLeftIcon2.transform.position = new Vector3(-1.15f, -0.92f, 0.0f);
        nextRightIcon2.transform.position = new Vector3(-1.15f, -1.95f, 0.0f);

        // �g�k
        nextLeftIcon2.transform.localScale = new Vector3(25.0f, 12.5f, 0.0f);
        nextRightIcon2.transform.localScale = new Vector3(25.0f, 12.5f, 0.0f);
    }

    public IEnumerator MoveIcon3()
    {
        float elapsedTime = 0.0f;   // �o�ߎ���
        while (elapsedTime < TOTAL_MOVE_TIME)  // ���v����
        {
            // �J�ڂ̐ݒ�
            float t = elapsedTime / TOTAL_MOVE_TIME;
            float ScaleX3 = Mathf.Lerp(0.0f, 15.0f, t);     // ���X���A�C�R���̉��̊g�k
            float ScaleY3 = Mathf.Lerp(0.0f, 7.5f, t);      // ���X���A�C�R���̏c�̊g�k

            // �g�k
            nextLeftIcon3.transform.localScale = new Vector3(ScaleX3, ScaleY3, 0.0f);
            nextRightIcon3.transform.localScale = new Vector3(ScaleX3, ScaleY3, 0.0f);

            // �^�C���X�V
            elapsedTime += Time.deltaTime;
            yield return null; // 1�t���[���ҋ@            
        }

        // �ŏI�␳
        nextLeftIcon3.transform.localScale = new Vector3(15.0f, 7.5f, 0.0f);
        nextRightIcon3.transform.localScale = new Vector3(15.0f, 7.5f, 0.0f);

        // ���̃A�C�R���̏���
        DestroyIcon();
        pf.ExecuteNextCharaIcon();
    }

    // �A�C�R���폜�֐�
    public void DestroyIcon()
    {
        if (puzzle.transform.GetChild(10).gameObject != null)   // ���X���E�A�C�R��
            DestroyImmediate(puzzle.transform.GetChild(11).gameObject);
        if (puzzle.transform.GetChild(9).gameObject != null)    // ���X�����A�C�R��
            DestroyImmediate(puzzle.transform.GetChild(10).gameObject);
        if (puzzle.transform.GetChild(8).gameObject != null)    // ���X�E�A�C�R��
            DestroyImmediate(puzzle.transform.GetChild(9).gameObject);
        if (puzzle.transform.GetChild(7).gameObject != null)    // ���X���A�C�R��
            DestroyImmediate(puzzle.transform.GetChild(8).gameObject);
        if (puzzle.transform.GetChild(6).gameObject != null)    // ���E�A�C�R��
            DestroyImmediate(puzzle.transform.GetChild(7).gameObject);
        if (puzzle.transform.GetChild(5).gameObject != null)    // �����A�C�R��
            DestroyImmediate(puzzle.transform.GetChild(6).gameObject);
        // �����̔ԍ��������
    }

    void SetEnemyBoard()
    {
        //�G�A�C�R��7�ƃ{�X�A�C�R��2��3��Unity�̃I�u�W�F�N�g�ɓ����

        //----���[���h�P----

        if (StageCount == 1)//�X�e�[�W�P
        {
            switch (RoundCount)
            {
                case 1://���E���h�P
                    Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round1.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    break;
                case 2://���E���h�Q
                    Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round2.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    break;
                case 3://���E���h�R
                    Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round3.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��

                    break;

            }
        }

        if (StageCount == 2)//�X�e�[�W�Q
        {
            switch (RoundCount)
            {
                case 1://���E���h1
                    Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round1.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//����
                    break;
                case 2://���E���h2
                    Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round2.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    break;
                case 3://���E���h3
                    Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round3.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    break;
            }
        }

        if (StageCount == 3)//�X�e�[�W�R
        {
            switch (RoundCount)
            {
                case 1://���E���h�P
                    Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round1.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//�E��
                    break;
                case 2://���E���h2
                    Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round2.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    break;
                case 3://���E���h3
                    Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round3.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_5, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);//�E��

                    break;
                case 4://���E���h4
                    Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round4.transform.SetParent(field.transform, false);

                    //��1���
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_5, 0.0f), Quaternion.identity);

                    //��2���
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                    //��3���
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    break;
            }
        }

        if (StageCount == 4)//�X�e�[�W�S
        {
            switch (RoundCount)
            {
                case 1://���E���h�P
                    Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round1.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);//�E��
                    break;
                case 2://���E���h2
                    Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round2.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);

                    break;
                case 3://���E���h3
                    Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round3.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��

                    break;
                case 4://���E���h4
                    Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round4.transform.SetParent(field.transform, false);

                    //��1���
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);

                    //��2���
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, -1.73f, 0.0f), Quaternion.identity);

                    //��3���
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    break;
            }
        }

        if (StageCount == 5)//�X�e�[�W�T
        {
            switch (RoundCount)
            {
                case 1://���E���h�P
                    Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round1.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    break;
                case 2://���E���h2
                    Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round2.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    break;
                case 3://���E���h3
                    Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round3.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��

                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��

                    break;
                case 4://���E���h4
                    Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round4.transform.SetParent(field.transform, false);

                    //��1���
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);

                    //��2���
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                    //��3���
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    break;
                case 5://���E���h5
                    Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round5.transform.SetParent(field.transform, false);
                    Instantiate(BossIcon, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);

                    break;
            }
        }


        //---���[���h�Q---
        if (StageCount == 6)//�X�e�[�W�P
        {
            switch (RoundCount)
            {
                case 1://���E���h�P
                    Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round1.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    break;
                case 2://���E���h�P
                    Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round2.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);//�E��
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);//����
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    break;
                case 3:
                    Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round3.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    break;
                case 4://���E���h4
                    Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round4.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    break;
                case 5:
                    Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round5.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_5, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);

                    break;
            }
        }
        else if (StageCount == 7)//�X�e�[�W�Q
        {
            switch (RoundCount)
            {
                case 1:
                    Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round1.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                    break;
                case 2:
                    Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round2.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);

                    break;
                case 3:
                    Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round3.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_5, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_5, 0.0f), Quaternion.identity);

                    break;
                case 4:
                    Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round4.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon1, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    break;

                case 5:
                    Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                    Round5.transform.SetParent(field.transform, false);

                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                    Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                    break;

            }
        }

            if (StageCount == 8)//�X�e�[�W�R
            {
                switch (RoundCount)
                {
                    case 1:
                        Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round1.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        break;
                    case 2:
                        Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round2.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        break;
                    case 3:
                        Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round3.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        break;
                    case 4:
                        Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round4.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;
                    case 5:
                        Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round5.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        break;

                }
            }

            if (StageCount == 9)//�X�e�[�W�S
            {
                switch (RoundCount)
                {
                    case 1:
                        Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round1.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        break;
                    case 2:
                        Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round2.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;
                    case 3:
                        Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round3.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;
                    case 4:
                        Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round4.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;

                    case 5:
                        Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round5.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;

                }
            }

            //---���[���h�R---
            if (StageCount == 10)//�X�e�[�W�T
            {
                switch (RoundCount)
                {
                    case 1:
                        Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round1.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        break;
                    case 2:
                        Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round2.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        break;
                    case 3:
                        Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round3.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;
                    case 4:
                        Round4 = Instantiate(Round4, new Vector3(332.0f, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round4.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_4, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_5, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_5, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        break;
                    case 5:
                        Round5 = Instantiate(Round5, new Vector3(332.0f, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round5.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        //Instantiate(BossIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        break;
                }
            }


            if (StageCount == 11)//�X�e�[�W�P
            {
                switch (RoundCount)
                {
                    case 1://���E���h�P
                        Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round1.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;
                    case 2://���E���h�P
                        Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round2.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;
                    case 3:
                        Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round3.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_5, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;
                    case 4://���E���h4
                        Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round4.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;
                    case 5:
                        Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round5.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_4, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_5, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_5, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;
                }
            }

            if (StageCount == 12)//�X�e�[�W�Q
            {
                switch (RoundCount)
                {
                    case 1:
                        Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round1.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        break;
                    case 2:
                        Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round2.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;
                    case 3:
                        Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round3.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_4, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        break;
                    case 4:
                        Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round4.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;

                    case 5:
                        Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round5.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;

                }
            }

            if (StageCount == 13)//�X�e�[�W�R
            {
                switch (RoundCount)
                {
                    case 1:
                        Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round1.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;
                    case 2:
                        Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round2.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        break;
                    case 3:
                        Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round3.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon8, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon8, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        break;
                    case 4:
                        Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round4.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_4, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_5, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_4, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_5, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;
                    case 5:
                        Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round5.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_4, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        break;

                }
            }

            if (StageCount == 14)//�X�e�[�W�S
            {
                switch (RoundCount)
                {
                    case 1:
                        Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round1.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;
                    case 2:
                        Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round2.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon8, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;
                    case 3:
                        Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round3.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_1, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_4, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        break;
                    case 4:
                        Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round4.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon8, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        break;

                    case 5:
                        Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round5.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_2, ENEMY_Y_4, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon8, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon7, new Vector3(ENEMY_X_3, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon8, new Vector3(ENEMY_X_5, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;

                }
            }

            if (StageCount == 15)//�X�e�[�W�T
            {
                switch (RoundCount)
                {
                    case 1:
                        Round1 = Instantiate(Round1, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round1.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        break;
                    case 2:
                        Round2 = Instantiate(Round2, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round2.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_2, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        break;
                    case 3:
                        Round3 = Instantiate(Round3, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round3.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon8, new Vector3(ENEMY_X_5, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        break;
                    case 4:
                        Round4 = Instantiate(Round4, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round4.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon1, new Vector3(ENEMY_X_1, ENEMY_Y_3, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon5, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon6, new Vector3(ENEMY_X_3, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_3, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        Instantiate(EnemyIcon8, new Vector3(ENEMY_X_4, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon2, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon8, new Vector3(ENEMY_X_4, ENEMY_Y_3, 0.0f), Quaternion.identity);
                        break;
                    case 5:
                        Round5 = Instantiate(Round5, new Vector3(ROUND_POS_X, ROUND_POS_Y, 0.0f), Quaternion.identity);
                        Round5.transform.SetParent(field.transform, false);

                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_1, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon4, new Vector3(ENEMY_X_2, ENEMY_Y_1, 0.0f), Quaternion.identity);
                        Instantiate(EnemyIcon3, new Vector3(ENEMY_X_2, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        //Instantiate(BossIcon3, new Vector3(ENEMY_X_4, ENEMY_Y_2, 0.0f), Quaternion.identity);

                        break;
                }
            }
    }
}


