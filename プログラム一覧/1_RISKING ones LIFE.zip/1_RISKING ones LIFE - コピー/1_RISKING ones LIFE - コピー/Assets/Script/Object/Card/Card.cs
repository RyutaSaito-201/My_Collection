/**
 * @file Card.cs
 * @brief �J�[�h�ʊǗ�
 */
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor.Rendering;
using UnityEngine;

public class Card : MonoBehaviour
{
    private static Vector3 center = new Vector3(0.0f, 0.0f, 0.0f);
    private float m_time = 0.0f;    //���Ԃ̃J�E���g�p
    private float endtime = 0.0f;   //�����̏I������
    //�ړI�n�ƌ��ݒn
    private Vector3 newPos;
    private Vector3 oldPos;
    private Vector3 newAngle;
    private Vector3 oldAngle;
    // �ړ����
    private ShuffleVar _shuffle;    // �V���b�t���p
    private bool _isShuffleEnd;     // �V���b�t���I���t���O
    private move_kind next;
	private move_kind move = move_kind.MAX;     // ���݂̈ړ��̎��
    private float _waitFaceDownTime;            // ��������܂ł̑҂�����
    private bool _isWaitEnd;                    // �҂����I��������

    // �J�[�h���
    private CardManager.kind _kind;             // �J�[�h�̎��
	private int _nomber;                        // �J�[�h�̃y�A�ԍ�

    private CardManager _cardMng;


    public enum move_kind//�ړ��̎��
    {
        TurnOver,       //�߂���
        Wait,           // ���ǂ��ҋ@
        FaceDown,       //�߂�
        Collect,        //���
        ShuffleStart,   //�V���b�t�����]�ځA��邾��
        ShuffleEnd,     //�V���b�t���j��]�ځA�ړI�n�Ɉړ�
        MAX
    };
    private struct ShuffleVar
    {
        public float oldDistans;
        public float newDistance;
        public float nowDistance;
        public float oldAngle;
        public float newAngle;
        public float nowAngle;
        public ShuffleVar(float old,float ned,float nod,float ola,float nea,float noa)
        {
            oldDistans = old;
            newDistance = ned;
            nowDistance = nod;
            oldAngle = ola;
            newAngle = nea;
            nowAngle = noa;
        }
    }
    void Start()
    {
        _cardMng = GameObject.Find("GameManager").GetComponent<CardManager>();
        _waitFaceDownTime = _cardMng.WaitFaceDownTime;
        next = move_kind.MAX;
        SetMove(move_kind.MAX);
        _shuffle = new ShuffleVar(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
    }

    void Update()
    {
        Animation();
	}
    //
    void Animation()
    {
        if (m_time <= 0) return;
        m_time -= Time.deltaTime;//�I�����Ԃ���0�ɂȂ�܂ň���
        switch (move)
        {
            //�J�[�h�̈ړ�
            case move_kind.TurnOver:
                {
                    this.transform.eulerAngles = new Vector3(oldAngle.x, oldAngle.y, lerp(newAngle.z, oldAngle.z));
                    this.transform.position = new Vector3(this.transform.position.x, sine_curve(oldPos.y, 2.0f), this.transform.position.z);
                }
                break;
            case move_kind.FaceDown:
                {
                    this.transform.eulerAngles = new Vector3(oldAngle.x, oldAngle.y, lerp(newAngle.z, oldAngle.z));
                    this.transform.position = new Vector3(this.transform.position.x, sine_curve(oldPos.y, 1.0f), this.transform.position.z);
                }
                break;
            case move_kind.Collect:
                this.transform.position = new Vector3(lerp(newPos.x, oldPos.x), lerp(newPos.y, oldPos.y), lerp(newPos.z, oldPos.z));
                break;
            case move_kind.ShuffleStart: 
                Swirl();
                break;
            case move_kind.ShuffleEnd:
                Swirl2();
                break;
            case move_kind.MAX:
                break;
            default:
                break;
        }
        //�Ō�A�ړI�n�փL�b�J�����킹��
        if (m_time <= 0)
        {
            switch (move)
            {
                case move_kind.TurnOver:
                    {
                        this.transform.eulerAngles = newAngle;
                        this.transform.position = oldPos;
                    }
                    break;
                case move_kind.Wait:
                    _isWaitEnd = true;
                    break;
                case move_kind.FaceDown:
                    {
                        this.transform.eulerAngles = newAngle;
                        this.transform.position = oldPos;
                    }
                    break;
                case move_kind.Collect:
                    this.transform.position = newPos;
                    break;
                case move_kind.ShuffleStart:
                    this.transform.position = oldPos;
                    SetMove(move_kind.ShuffleEnd);
                    break;
                case move_kind.ShuffleEnd:
                    this.transform.position = newPos;
                    _isShuffleEnd = true;
                    break;
                case move_kind.MAX:
                    break;
                default:
                    break;
            }
            //if (next != move_kind.MAX && next != move_kind.Wait)
            //{
                if(move == move_kind.TurnOver) next = move_kind.Wait;
                else next = move_kind.MAX;
                SetMove(next);
            //}
        }
    }

    // ===== getter�Esetter =====
    public move_kind moveKind { get { return move; } }
    // �J�[�h�̎��
    public CardManager.kind kind { get { return _kind; } set { _kind = value; } }
    // �J�[�h�̔ԍ�
	public int number { get { return _nomber; } set { _nomber = value; } }
    // �V���b�t���I���t���O
    public bool isShuffleEnd { get { return _isShuffleEnd; } set { _isShuffleEnd = value; } }
    // ��������܂ł̑҂����ԏI���t���O
    public bool isWaitEnd { get { return _isWaitEnd; } }

	//���`���
	float lerp(float now, float old)
    {
        float f = m_time / endtime;
        f = (f * old) + ((1 - f) * now);
        return f;
    }
    //�T�C���J�[�u
    float sine_curve(float old, float size)
    {
        float f = 1.0f - (m_time / endtime);
        f = Mathf.Deg2Rad * (180.0f * f);
        f = old + (Mathf.Sin(f) * size);

        return f;
    }
    //�ړ��̎�ނ̕ύX
    public void SetMove(move_kind kind)
    {
        if (m_time > 0)
        {
            next = kind;
            return;
        }
        //old�Ɍ��݂̍��W������
        oldPos = this.transform.position;
        oldAngle = this.transform.eulerAngles;
        switch (kind)
        {
            //move_kind�̕ύX
            //newPos,Angle�ɖړI�n������
            //endTime�Ɉړ��ɂ����鎞�Ԃ�����
            case move_kind.TurnOver:
                move = move_kind.TurnOver;
                newAngle = new Vector3(0.0f, 0.0f, 180.0f);
                endtime = 0.7f;
                break;
            case move_kind.Wait:
                move = move_kind.Wait;
                _isWaitEnd = false;
                endtime = _waitFaceDownTime;
                break;
            case move_kind.FaceDown:
                move = move_kind.FaceDown;
                newAngle = new Vector3(0.0f, 0.0f, 0.0f);
                _isWaitEnd = false;
                endtime = 0.5f;
                break;
            case move_kind.Collect:
                move = move_kind.Collect;
                newPos = new Vector3(0.0f, 1.0f, 0.0f);
                endtime = 5.0f;
                break;
            case move_kind.ShuffleEnd:
                { 
                    float oa, na;
                    move = move_kind.ShuffleEnd;
                    oa = (_shuffle.oldAngle * 180 / Mathf.PI) % 360.0f;
                    na = (_shuffle.newAngle * 180 / Mathf.PI) % 360.0f;
                    float f = na - oa;
                    if(f <= 0.0f) { f += 360.0f; }
                    float distance = _shuffle.oldDistans - _shuffle.newDistance;
                    distance = Mathf.Sqrt(distance * distance);
                    endtime = ((f / 720.0f) * 5.0f) + (distance * 0.5f);
                    f *= Mathf.Deg2Rad;
                    _shuffle.newAngle = f;
                }
                break;
            default:
                endtime = 0.0f;
                break;
        }
        m_time = endtime;//m_time��0�ɂȂ�܂Ō��炵�Ă����̂�endTime����n�߂�
    }
    //�}�l�[�W���[����Ăяo��
    public void SetShuffle(Vector3 pos)
    {
        _isShuffleEnd = false;
        move = move_kind.ShuffleStart;
        oldPos = this.transform.position;
        oldAngle = this.transform.eulerAngles;
        newPos = pos;
        _shuffle.oldDistans = GetDistance(oldPos);
        _shuffle.newDistance = GetDistance(newPos);
        _shuffle.nowDistance = _shuffle.oldDistans;
        _shuffle.oldAngle = GetAngle(oldPos);
        _shuffle.newAngle = GetAngle(newPos);
        _shuffle.nowAngle = _shuffle.oldAngle;
        endtime = 4.0f;
        m_time = endtime;
    }
    public bool isPlay()
    {
        if(move == move_kind.MAX || move == move_kind.Wait) return false;
        else return true;
        //return m_time >= 0;
    }
    //���]�ځA��邾��
    private void Swirl()
    {
        float f = 1.0f - (m_time / endtime);
        _shuffle.nowAngle = (Mathf.Deg2Rad * (360.0f * f)) + _shuffle.oldAngle;
        this.transform.position = GetAnglePos(_shuffle.nowAngle, _shuffle.nowDistance);
    }
    //���S��������̕������擾
    private float GetAngle(Vector3 pos)
    {
        float x, z,angle;
        x = pos.x - center.x;
        z = pos.z - center.z;
        angle = Mathf.Atan2(x, z);
        return angle;
    }
    //���S��������̋������擾
    private float GetDistance(Vector3 pos)
    {
        float x, z, distance;
        x = pos.x - center.x;
        z = pos.z - center.z;
        distance = Mathf.Sqrt((x * x) + (z * z));
        return distance;
    }
    private Vector3 GetAnglePos(float angle,float distance)
    {
        Vector3 v;
        v.x = (Mathf.Sin(angle) * distance) + center.x;
        v.y = oldPos.y;
        v.z = (Mathf.Cos(angle) * distance) + center.z;
        return v;
    }
    static public void SetCenter(Vector3 pos)
    {
        center = pos;
    }
    //���]�ځAnewPos�֌�����
    private void Swirl2()
    {
        float f = 1.0f - (m_time / endtime);
        _shuffle.nowAngle = (_shuffle.newAngle * f) + _shuffle.oldAngle;
        _shuffle.nowDistance = ((1 - f) * _shuffle.oldDistans) + (f * _shuffle.newDistance);
        this.transform.position = GetAnglePos(_shuffle.nowAngle, _shuffle.nowDistance);
    }
}
