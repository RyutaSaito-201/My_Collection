using CartoonFX;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DrugManager : MonoBehaviour
{
    private List<GameObject> DrugList;//��̃��X�g
    private List<Drug> _drug;
    private List<Drug> _poison;
    private List<GameObject> _poisonEffe = new List<GameObject>();   // ����G�t�F�N�g���X�g
    private DrugState state;
    private GameObject useDrug;//�I�𒆂̖�
    public GameObject Prefab;//��̃v���n�u
    public float Distance;//��Ƃ��̃I�u�W�F�N�g�Ƃ̋���
    public int DrugNum;//��̐�
    public int PoisonNum;//�ł̐�
    private bool use;
    private DrugState oldState;
    public enum DrugState { Select,Conf,USE,MAX};    // Start is called before the first frame update

    private EffectManager _effectMng;

    void Start()
    {
        _effectMng = Camera.main.GetComponent<EffectManager>();

        use = false;
        state = DrugState.Select;
        oldState = state;
        DrugList = new List<GameObject>();
        _drug = new List<Drug>();
        _poison = new List<Drug>();
        //static�̃Z�b�g
        Drug.SetCenter(this.gameObject);
        Drug.SetDistance(Distance);
        Drug.SetDrugPosP(GameObject.Find("DrugPos"));
        Drug.SetDrugPosE(GameObject.Find("DrugPosEnemy"));
        Drug.SetEnemy(GameObject.Find("Enemy").GetComponent<EnemyStatus>());
        Drug.SetPlayer(GameObject.Find("Player").GetComponent<PlayerStatus>());
        //�ł����߂鏈��
        if (DrugNum <= PoisonNum) PoisonNum = 2;
        //�z���p��
        int[] ary = new int[DrugNum];
        for (int i = 0; i < DrugNum; ++i)
        {
            ary[i] = i;
        }
        //�V���b�t��
        for (int i = 0; i < DrugNum; ++i)
        {
            int j = UnityEngine.Random.Range(0, DrugNum);
            int b = ary[j];
            ary[j] = ary[i];
            ary[i] = b;

        }
        
        bool bb;
        
        //��̐���,���X�g�ɒǉ�
        for (int i = 0;i < DrugNum;++i)
        {
            bb = false;
            GameObject go = Instantiate(Prefab);
            float angle = i * (360 / DrugNum);
            go.GetComponent<Drug>().SetAnglePos(angle);
            go.GetComponent<Drug>().SetPoison(false);
            
            for(int j = 0;j < PoisonNum;++j)
            {
                if(i == ary[j])
                {
                    bb = true;
                }
            }
            
            if(bb)
            {
                _poison.Add(go.GetComponent<Drug>());
                go.GetComponent<Drug>().SetPoison(true);
                go.name = "doku";
                // --- �ŃG�t�F�N�g�����A�e�q�t��
                GameObject effe = _effectMng.SpawnEffect(4, go.transform);
                effe.transform.SetParent(go.transform, true);
                _poisonEffe.Add(effe);      // ����G�t�F�N�g���X�g�ɒǉ�

                Debug.Log("�ł��ł���");
            }
            else
            {
                _drug.Add(go.GetComponent<Drug>());
            }
            
            DrugList.Add(go);
        }
        EffectOff();

        //
        GameObject.Find("kusuriire_kaiten").GetComponent<Rotate>()._speed(2.5f);
        Drug._speed(2.5f);



    }

    // Update is called once per frame
    public void UpdateState()
    {
        
        oldState = state;
        switch (state)
        {
            case DrugState.Select:
                {
                    //�������������I������
                    { 
                        if (Input.GetMouseButtonDown(0))
                        {
                            Restore();
                            RaycastHit hit = new RaycastHit();
                            Ray ray = new Ray();
                            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                            if (Physics.Raycast(ray.origin, ray.direction, out hit, Mathf.Infinity))
                            {
                                if (hit.collider.CompareTag("c"))
                                {
                                    useDrug = hit.collider.gameObject;
                                    useDrug.GetComponent<Drug>().UsePlayer();
                                    state = DrugState.Conf;
                                }
                            }
                        }                        
                    }
                }
                break;
            case DrugState.Conf:
                {
                    //���I��ł�����
                    if (Input.GetMouseButtonDown(0))
                    {
                        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                        RaycastHit hit;
                        if (Physics.Raycast(ray, out hit, 50.0f))
                        {
                            //������������A�j���[�V�����Đ�
                            if (useDrug.GetComponent<BoxCollider>() == hit.collider)
                            {
                                useDrug.GetComponent<Drug>().SetAnim();
                                state = DrugState.USE;
                                _drug.Remove(useDrug.GetComponent<Drug>());
                                _poison.Remove(useDrug.GetComponent<Drug>());
                                EffectOff();
                                DrugList.Remove(useDrug);
                                useDrug = null;
                                use = true;
                                Debug.Log(DrugList.Count);
                                break;
                            }
                            
                        }
                        //������̂�I��ł�����O�ɖ߂�
                        Restore();
                    }                  
                }
                
                break;
            case DrugState.USE:
                
                break;
        }
    }
    //���I��ł����Ԃł����ture
    public bool isSelect()
    {
        if((state == DrugState.Select) && (oldState == DrugState.Select))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public void Restore()
    {
        if (useDrug != null)
        { useDrug.GetComponent<Drug>().SetReturn();
            useDrug = null;
        }
        state = DrugState.Select;
    }
    public int GetCount()
    {
        return DrugList.Count;
    }
    public void UseDrug()
    {
        // �g�p�����������_���őI��
        int i = (int)Random.Range(0, DrugList.Count - 1);
        // �d�l�A�j���[�V�����Đ�
        DrugList[i].GetComponent<Drug>().UseEnemy();

        // --- ���X�g����폜
        if(DrugList[i].GetComponent<Drug>()._bPosion)
        { 
            _poison.Remove(DrugList[i].GetComponent<Drug>());
        }
        else
        { 
            _drug.Remove(DrugList[i].GetComponent<Drug>());
        }
        
        DrugList.Remove(DrugList[i]);
    }
    public void UseTrueDrug()
    {
        int i = (int)Random.Range(0, _drug.Count - 1);
        _drug[i].UseEnemy();
        _drug.Remove(DrugList[i].GetComponent<Drug>());
        DrugList.Remove(DrugList[i]);
        
    }
    //�G�t�F�N�g���I���ɂ���
    public void EffectOn()
    {
        foreach(var effe in _poisonEffe)
        {
            effe.GetComponent<ParticleSystem>().Play();
        }
    }
    //�G�t�F�N�g���I�t�ɂ���
    public void EffectOff()
	{
		foreach (var effe in _poisonEffe)
		{
			effe.GetComponent<ParticleSystem>().Stop();
		}
	}

	public bool _use { get { return use; } set { use = value; } }
}
