using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drug : MonoBehaviour
{
    static GameObject usePlayerPos;     //�I�������򂪌������ʒu
    static GameObject useEnemyPos;      //�I�������򂪌������ʒu
    static private GameObject center;   //DrugManager�������Ă�I�u�W�F�N�g
    static private float distance;
    private Animator anim;              //��g�p���̃A�j���[�V����
    private bool useman;
    private float timer;
    private DrugState state;            //�����̃X�e�[�g
    static private float speed = 2.5f;  //��鑁��
    private float angle;                //center���猩���p�x
    private bool bPoison = false;       //�ł��ǂ���
    static private PlayerStatus ps;
    static private EnemyStatus es;
    private bool bPlayer;
    public enum DrugState {NONE,ROTATE,MOVE,RETURN,MAX };

    // Start is called before the first frame update
    void Start()
    {
        anim = gameObject.GetComponent<Animator>();
        state = DrugState.ROTATE;
    }
    private void Update()
    {
        angle += speed * Time.deltaTime;
        switch (state)
        {
            case DrugState.ROTATE:
                
                transform.position = SetAnglePos();
                break;
            case DrugState.MOVE:
                timer += Time.deltaTime;
                if(bPlayer)     // �v���C���[�p�A�j���[�V����
                {
                    transform.position = Vector3.Lerp(this.transform.position, usePlayerPos.transform.position, timer);
                }
                else
                {
                    transform.position = Vector3.Lerp(this.transform.position, useEnemyPos.transform.position, timer);
                }
                if(!bPlayer)    // �G�p�A�j���[�V����
                {
                    if (timer > 3.0f)
                    {
                        Debug.Log("�G�A�j��");
                        anim.Play("UseEnemyDrug", 0, 0.0f); // �A�j���[�V����
                        state = DrugState.MAX;
                    }
                }
                
                break;
            case DrugState.RETURN:
                state = DrugState.ROTATE;
                break;
            default:
                break;
        }
    }
    //�A�j���[�V�����t���O�𗧂Ă�
    public void SetAnim()
    {
        Debug.Log("�v���C���[�A�j��");
        state = DrugState.MAX;
        anim.Play("DrugAnim", 0, 0.0f);
    }
    //�A�j���[�V�����I�����Ăяo�����֐�
    public void OnAnimationEnd()
    {
        if(bPlayer)
        {
            if (bPoison == true)
            {
                //ps.AddDamage(99);
                GameManager.instance.SetGameEnd(GameManager.endKind.PlayerDrugDead);    // �łŎ��ʉ��o���Đ����ăQ�[���I��
            }
            else
            {
                Debug.Log("�񕜂�������");
                ps.DebuffClear();
			}
        }
        else
        {
            if (bPoison == true)
            {
                //for(int i = 0;i < 20;++i)
                //{
                //    es.AddDamage();
                //}
                GameManager.instance.SetGameEnd(GameManager.endKind.EnemyDrugDead);     // �łŎ��ʉ��o���Đ����ăQ�[���I��
            }
            else
            {
                es.DebuffClear();

                // �^�[�����
                GameManager.instance.SetPause(false);   // ��bUI���������邽�߈�xOFF
				GameManager.instance.ChangeTurn();
			}
        }

        Debug.Log("��j��");
        center.GetComponent<DrugManager>().Restore();
        Destroy(this.gameObject);
    }
    static public void SetDistance(float f)
    {
        distance = f;
    }
    static public void SetCenter(GameObject go)
    {
        center = go;
    }
    static public void SetDrugPosP(GameObject go)
    {
        usePlayerPos = go;
    }
    static public void SetDrugPosE(GameObject go)
    {
        useEnemyPos = go;
    }
    private float GetAngle(Vector3 pos)
    {
        float x, z, angle;
        x = pos.x - center.transform.position.x;
        z = pos.z - center.transform.position.z;
        angle = Mathf.Atan2(x, z);
        return angle;
    }
    public void SetAnglePos(float fAngle)
    {
        float a = fAngle * Mathf.Deg2Rad;
        Vector3 v;
        v.x = (Mathf.Sin(a) * distance) + center.transform.position.x;
        v.y = center.transform.position.y;
        v.z = (Mathf.Cos(a) * distance) + center.transform.position.z;
        this.transform.position = v;
        angle = fAngle;
    }
    private Vector3 SetAnglePos()
    {
        float a = angle * Mathf.Deg2Rad;
        Vector3 v = center.transform.position;
        v.x = (Mathf.Sin(a) * distance) + center.transform.position.x;
        v.z = (Mathf.Cos(a) * distance) + center.transform.position.z;
        return v;
    }
    public void UseEnemy()
    {
        bPlayer = false;
        state = DrugState.MOVE;
    }
    public void UsePlayer()
    {
        bPlayer = true;
        state = DrugState.MOVE;
    }
    public void SetReturn()
    {
        state = DrugState.RETURN;
    }
    //�ł̃t���O��ύX
    public void SetPoison(bool b)
    {
        bPoison = b;
    }
    static public void SetEnemy(EnemyStatus e)
    { es = e; }
    static public void SetPlayer(PlayerStatus p)
    { ps = p; }
    
    public bool _bPosion { get { return bPoison; } }
    static public void _speed(float f) { speed = f; }
}
