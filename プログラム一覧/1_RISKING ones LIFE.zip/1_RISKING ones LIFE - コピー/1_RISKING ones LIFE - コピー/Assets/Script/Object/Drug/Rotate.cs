using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate : MonoBehaviour
{
    private float speed;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.eulerAngles = new Vector3(0.0f, this.transform.eulerAngles.y + (Time.deltaTime * speed), 0.0f);
    }
    public void _speed(float f) { speed = f; }
}
