#ifndef __ArrowUI_H__
#define __ArrowUI_H__

#include <DirectX.h>
#include <DirectXMath.h>
#include "Sprite.h"
#include "CameraBase.h"
#include "CameraDebug.h"
#include <iostream>
#include <tuple>

using namespace std;

class ArrowUI
{
public:
	ArrowUI();
	~ArrowUI();

	tuple <DirectX::XMFLOAT4, DirectX::XMFLOAT2> Update(int VectorSel, DirectX::XMFLOAT3 Pos, DirectX::XMFLOAT3 Size);

	void Draw(int NowPhase, DirectX::XMFLOAT4 Pos, DirectX::XMFLOAT2 Size, CameraBase* m_pCamera);
	void SetDrawArrow(DirectX::XMFLOAT4 Pos, float RotY, DirectX::XMFLOAT2 size, int NowPhase, CameraBase* m_pCamera);


	enum  VectorPhase
	{
		VECTOR_PHASE_1 = 1,		// �����	
		VECTOR_PHASE_2 = 2,	// ������
		VECTOR_PHASE_3 = 3,	// �E����
		MAX_PHASE = 4,	// ������
	};

	enum  VectorKind
	{
		VECTOR_UP = 1,		// �����	
		VECTOR_DOWN = 2,	// ������
		VECTOR_RIGHT = 3,	// �E����
		VECTOR_LEFT = 4,
		MAX_VECTOR = 5,	// ������
	};

private:
	Texture* m_pTexture[MAX_VECTOR];
	CameraBase* m_pCamera;

	DirectX::XMFLOAT4 m_ArrowAlpha;
	DirectX::XMFLOAT3 m_pos, m_look, m_up;	// �r���[�s��̐ݒ�ɕK�v�ȕϐ�
};

#endif // !__ArrowUI_H__


