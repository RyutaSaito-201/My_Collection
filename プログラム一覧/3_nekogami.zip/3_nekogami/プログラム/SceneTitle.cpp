#include "SceneTitle.h"
#include "Input.h"
#include <Xinput.h>

//�ǂݍ��݃t�@�C��
#define FILE_NAME ("Assets/Texture/SceneTitle.png")
#define FILE_NAME2 ("Assets/Texture/Start.png")
#define FILE_NAME3 ("Assets/Texture/Start2.png")
#define FILE_NAME4 ("Assets/Texture/BackGround.png")
#define FILE_NAME5 ("Assets/Texture/BackGround2.png")

//���͐����ǉ�
//#define FILE_NAME5 ("Assets/Texture/ReStart.png")
//#define FILE_NAME6 ("Assets/Texture/ReStart2.png")

#define MAX_TEXTURE (7)

XINPUT_STATE state3;
int p;

SceneTitle::SceneTitle()
	:m_UIAlpha(1.0f, 1.0f, 1.0f, 1.0f)
	,m_pBGM(nullptr)
	,m_pBGMSpeaker(nullptr)
	,m_bTrigger(false)
	, m_pEffectMng(nullptr)
	, m_nframe(0)
	, m_nAnimeNo(0)
	, m_bAnimeNo(false)
	, m_pCamera(nullptr)
	, m_BackPos(640.0f, 360.0f, 0.0f)
	, m_BackPos2(1918.7f, 360.0f, 0.0f)
	, m_BackSize(1280.0f, -720.0f)

{
	for (p = 0; p < MAX_TEXTURE; p++)
	{
		m_pTexture[p] = new Texture();
	}

	if (FAILED(m_pTexture[0]->Create(FILE_NAME)))
	{
		MessageBox(NULL, "SceneTitle SceneTitle.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[1]->Create(FILE_NAME2)))
	{
		MessageBox(NULL, "SceneTitle Start.png", "Error", MB_OK);
	}
	if (FAILED(m_pTexture[2]->Create(FILE_NAME3)))
	{
		MessageBox(NULL, "SceneTitle Start.png", "Error", MB_OK);
	}
	if (FAILED(m_pTexture[3]->Create(FILE_NAME4)))
	{
		MessageBox(NULL, "SceneTitle BackGround.png", "Error", MB_OK);
	}
	if (FAILED(m_pTexture[4]->Create(FILE_NAME5)))
	{
		MessageBox(NULL, "SceneTitle BackGround.png", "Error", MB_OK);
	}

	m_pBGM = LoadSound("Assets/Sound/Title.wav", true);

	m_pBGMSpeaker = PlaySound(m_pBGM);
	m_pBGMSpeaker->SetVolume(0.5f);

	m_pEffectMng = new EffectMng("Assets/Texture/TitleSceneBG.png");	//����
	m_pCamera = new CameraBase();
}

SceneTitle::~SceneTitle()
{
	delete m_pCamera;
	m_pCamera = nullptr;

	delete m_pEffectMng;
	m_pEffectMng = nullptr;

	for (p = 0; p < MAX_TEXTURE; p++)
	{
		if (m_pTexture[p])
		{
			delete m_pTexture[p];
			m_pTexture[p] = nullptr;
		}
	}
}

void SceneTitle::Update(SceneManager* pSceneMng)
{
	if (m_BackPos.x > -640.0f)
	{
		m_BackPos.x -= 1.0f;
		m_BackPos2.x -= 1.0f;
	}

	if (m_BackPos.x == -640.0f)
	{
		m_BackPos.x = 1918.5f;

	}

	if (m_BackPos2.x == -640.0f)
	{
		m_BackPos2.x = 1918.5f;
	}

	// �R���g���[���[���擾
	XInputGetState(0, &state3);
	if (IsKeyTrigger(VK_SPACE) || state3.Gamepad.wButtons & XINPUT_GAMEPAD_A)
	{
		m_bTrigger = true;

		pSceneMng->SetNextScene(SCENE_STORY);
		m_pBGMSpeaker->Stop();
	}

	//�����G�t�F�N�g
	if (m_nframe >= 3)
	{
		m_nframe = 0;
		//�A�j���̃R�}��؂�ւ�
		if (!m_bAnimeNo)
		{
			m_nAnimeNo++;
			if (m_nAnimeNo >= 130)//156
			{
				m_nAnimeNo = 130;//0
				m_bAnimeNo = true;
			}
		}
		else
		{
			m_nAnimeNo--;
			if (m_nAnimeNo <= 5)
			{
				m_nAnimeNo = 5;
				m_bAnimeNo = false;
			}
		}
	}
	m_pEffectMng->Update({ 13.0f, 12.0f }, { 13.0f, 12.0f },
		m_nAnimeNo, { -5.5f,0.0f,0.0f }, 13);
	m_nframe++;
}

void SceneTitle::Draw()
{
	m_pEffectMng->Update({ 13.0f, 12.0f }, { 13.0f, 12.0f }, m_nAnimeNo, { -5.5f, 0.0f, 0.0f }, 13);
	m_pEffectMng->Draw(m_pCamera->GetViewMatrix(), m_pCamera->GetProjyectionMatrix(), -90.0f, { 27.0f, 15.0f });

	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			640.0f, 280.0f, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(800.0f, -480.0f));
	Sprite::SetTexture(m_pTexture[0]);
	Sprite::Draw();
}

void SceneTitle::DrawStart()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			640.0f, 600.0f, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(250.0f, -75.0f));

	if (m_bTrigger == false)
	{
		Sprite::SetTexture(m_pTexture[1]);
	}
	else
	{
		Sprite::SetTexture(m_pTexture[2]);
	}

	Sprite::Draw();
}

void SceneTitle::DrawBack()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			m_BackPos.x, m_BackPos.y, m_BackPos.z
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(m_BackSize.x, m_BackSize.y));
	Sprite::SetTexture(m_pTexture[3]);
	Sprite::Draw();
}
void SceneTitle::DrawBack2()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			m_BackPos2.x, m_BackPos2.y, m_BackPos2.z
		);

	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(m_BackSize.x, m_BackSize.y));
	Sprite::SetTexture(m_pTexture[4]);
	Sprite::Draw();
}
