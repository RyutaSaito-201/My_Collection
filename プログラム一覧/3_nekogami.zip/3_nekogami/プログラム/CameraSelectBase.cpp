#include "CameraSelectBase.h"

CameraSB::CameraSB()
	:m_pos(-0.5f, -1.5f, -3.6f), m_look(1.0f, 0.0f, 0.0f), m_up(0.0f, 1.0f, 0.0f)
	,m_fovy(60.0f / 180.0f* 3.141592), m_aspect(16.0f / 9.0f), m_near(0.3f), m_far(100.0f)
{

}

CameraSB::~CameraSB()
{

}

void CameraSB::Update()
{

}

DirectX::XMFLOAT4X4 CameraSB::GetViewMatrix()
{
	DirectX::XMFLOAT4X4 mat;
	DirectX::XMMATRIX view;
	view = DirectX::XMMatrixLookAtLH(    // �r���[�s��̐ݒ�
		DirectX::XMVectorSet(m_pos.x, m_pos.y, m_pos.z, 0.0f),
		DirectX::XMVectorSet(m_look.x, m_look.y, m_look.z, 0.0f),
		DirectX::XMVectorSet(m_up.x, m_up.y, m_up.z, 0.0f)
	);
	view = DirectX::XMMatrixTranspose(view);    // �]�u�s��ɕϊ�
	DirectX::XMStoreFloat4x4(&mat, view);    // XMMATRIX�^����XMFLOAT4X4�^(mat[1]�֕ϊ����Ċi�[)
	return mat;

}

DirectX::XMFLOAT4X4 CameraSB::GetProjyectionMatrix()
{
	DirectX::XMFLOAT4X4 mat;
	DirectX::XMMATRIX proj;
	proj = DirectX::XMMatrixPerspectiveFovLH(    // �v���W�F�N�V�����s��̐ݒ�
		m_fovy, m_aspect, m_near, m_far);
	proj = DirectX::XMMatrixTranspose(proj);    // �]�u�s��ɕϊ�
	DirectX::XMStoreFloat4x4(&mat, proj);    // XMMATRIX�^����XMFLOAT4X4�^(mat[2]�֕ϊ����Ċi�[)
	return mat;
}

void CameraSB::SetPos(float PosX, float PosY, float PosZ)
{
	m_pos.x = PosX;
	m_pos.y = PosY;
	m_pos.z = PosZ;
}

void CameraSB::Setlook(float LookX, float LookY, float LookZ)
{
	m_look.x = LookX;
	m_look.y = LookY;
	m_look.z = LookZ;
}

void CameraSB::SetUp(float UpX, float UpY, float UpZ)
{
	m_up.x = UpX;
	m_up.y = UpY;
	m_up.z = UpZ;
}

DirectX::XMFLOAT3 CameraSB::GetPos()
{
	return m_pos;
}
