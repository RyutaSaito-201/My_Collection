#ifndef EFFECT_MNG_H__
#define EFFECT_MNG_H__

#include <DirectXMath.h>
//#include "Texture.h"
//#include "Effect.h"
#include "MoveEmitter.h"

class EffectMng
{
public:
	EffectMng(const char* textureFile);
	~EffectMng();
	//������split��UVScale��x�̒l�ɂ��킹��
	void Update(DirectX::XMFLOAT2 UVPos, DirectX::XMFLOAT2 UVScale, int No, DirectX::XMFLOAT3 pos, int split);
	void Draw(DirectX::XMFLOAT4X4 view, DirectX::XMFLOAT4X4 proj, float RotateX, DirectX::XMFLOAT2 size);

private:
	MoveEmitter* m_pMoveEmitter;
	//Texture* m_pTexture;
	Effect* m_pEffect;
	bool m_bEffect;
};

#endif
