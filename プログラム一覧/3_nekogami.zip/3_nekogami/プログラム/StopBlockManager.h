#ifndef ___STOPBLOCK_MNG_H___
#define ___STOPBLOCK_MNG_H___

#include <DirectXMath.h>
#include "Geometory.h"
#include "Model.h"
#include "Shader.h"
#include "CameraDebug.h"

#define BLOCK_KIND (4)

///////////////////////
// CreateBlock�֐�
// ����nKind�̎��
// 1.�����`�u���b�N
// 2.�Q�}�X�u���b�N
// 3.�R�}�X�u���b�N
// 4. L���^�u���b�N
///////////////////////
class StopBlockManager
{
public:
	StopBlockManager();
	void CreateBlock(float ScalingX, float ScalingY, float ScalingZ, float posX,
		float posY, float posZ, float radX, float radY, float radZ, int nKind);
	//virtual void Update() = 0;
	void Draw(DirectX::XMFLOAT4X4 mat[3]);

	DirectX::XMFLOAT3 GetPos();
	DirectX::XMFLOAT3 GetSize();
	void SetPos(DirectX::XMFLOAT3 pos);

protected:
	Model* m_pModel[BLOCK_KIND];
	VertexShader* m_pVS[BLOCK_KIND];
	CameraBase* m_pCamera;

	DirectX::XMFLOAT3 m_Size;
	DirectX::XMFLOAT3 m_pos;		// ���S���W
	DirectX::XMFLOAT3 m_rad;
	DirectX::XMFLOAT3 m_CollSize;
	int m_nKind;	// �ǂ̎�ނŕ\�����邩
	DirectX::XMFLOAT3 m_CameraPos;
	DirectX::XMFLOAT3 m_CameraLook;
	//DirectX::XMFLOAT4X4 m_mat[3];
};

#endif // !___BLOCK_MNG_H___
