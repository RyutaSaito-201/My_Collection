#ifndef ___CAMERA_DEBUG_H___
#define ___CAMERA_DEBUG_H___

#include "Input.h"
#include "CameraBase.h"

class CameraDebug
	: public CameraBase
{
public:
	CameraDebug();
	~CameraDebug();
	//void Update();
};

#endif // !___CAMERA_DEBUG_H___
