#include "SelectCamera.h"

SelectCamera::SelectCamera()
	:m_pSelectPlayer(nullptr)
	, m_Camerapos(0.0f, 0.0f)
{
	
}

SelectCamera::~SelectCamera()
{

}

void SelectCamera::Update()
{
	if (m_pSelectPlayer)
	{
		m_Camerapos.x = m_pSelectPlayer->GetPos().x;
		m_Camerapos.y = m_pSelectPlayer->GetPos().y;
	}


}

void SelectCamera::SetPlayer(SelectPlayer * player)
{
	m_pSelectPlayer = player;
}

DirectX::XMFLOAT2 SelectCamera::GetCameraPos()
{
	return m_Camerapos;
}
