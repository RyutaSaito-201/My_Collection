#include "StopBlockManager.h"

StopBlockManager::StopBlockManager()
	: m_CameraPos(-6.0f, 3.0f, -5.0f)
	, m_CameraLook(-6.0f, 0.0f, 0.0f)
{
	// �c�̕�
	m_pModel[0] = new Model();
	if (!m_pModel[0]->Load("Assets/Model/StopBlock/01.fbx", 1.0f, Model::XFlip))
	{
		MessageBox(NULL, "lengthWall", "Error", MB_OK);
	}
	m_pVS[0] = new VertexShader();
	if (FAILED(m_pVS[0]->Load("Assets/Shader/VS_Model.cso")))
	{
		MessageBox(nullptr, "VS_Model.cso", "Error", MB_OK);
	}
	m_pModel[0]->SetVertexShader(m_pVS[0]);	//���f���֓ǂݍ��񂾒��_�V�F�[�_�[��ݒ�

	// ���̕�
	m_pModel[1] = new Model();
	if (!m_pModel[1]->Load("Assets/Model/StopBlock/02.fbx", 1.0f, Model::XFlip))
	{
		MessageBox(NULL, "sideWall", "Error", MB_OK);
	}
	m_pVS[1] = new VertexShader();
	if (FAILED(m_pVS[1]->Load("Assets/Shader/VS_Model.cso")))
	{
		MessageBox(nullptr, "VS_Model.cso", "Error", MB_OK);
	}
	m_pModel[1]->SetVertexShader(m_pVS[1]);	//���f���֓ǂݍ��񂾒��_�V�F�[�_�[��ݒ�

	// �c�̕�(���~��)
	m_pModel[2] = new Model();
	if (!m_pModel[2]->Load("Assets/Model/StopBlock/03.fbx", 1.0f, Model::XFlip))
	{
		MessageBox(NULL, "lengthWall", "Error", MB_OK);
	}
	m_pVS[2] = new VertexShader();
	if (FAILED(m_pVS[2]->Load("Assets/Shader/VS_Model.cso")))
	{
		MessageBox(nullptr, "VS_Model.cso", "Error", MB_OK);
	}
	m_pModel[2]->SetVertexShader(m_pVS[2]);	//���f���֓ǂݍ��񂾒��_�V�F�[�_�[��ݒ�

	// ���̕�(���~��)
	m_pModel[3] = new Model();
	if (!m_pModel[3]->Load("Assets/Model/StopBlock/Lblock.fbx", 1.0f, Model::XFlip))
	{
		MessageBox(NULL, "sideWall", "Error", MB_OK);
	}
	m_pVS[3] = new VertexShader();
	if (FAILED(m_pVS[3]->Load("Assets/Shader/VS_Model.cso")))
	{
		MessageBox(nullptr, "VS_Model.cso", "Error", MB_OK);
	}
	m_pModel[3]->SetVertexShader(m_pVS[3]);	//���f���֓ǂݍ��񂾒��_�V�F�[�_�[��ݒ�

	m_pCamera = new CameraDebug();
}

void StopBlockManager::CreateBlock(float ScalingX, float ScalingY, float ScalingZ,
	float posX, float posY, float posZ, float radX, float radY, float radZ, int nKind)
{
	m_Size.x = ScalingX;
	m_Size.y = ScalingY;
	m_Size.z = ScalingZ;
	m_pos.x = posX;
	m_pos.y = posY;
	m_pos.z = posZ;
	m_rad.x = radX;
	m_rad.y = radY;
	m_rad.z = radZ;
	m_nKind = nKind;
}

void StopBlockManager::Draw(DirectX::XMFLOAT4X4 mat[3])
{
	// �J�����̃A�b�v�f�[�g
	m_CameraPos.x += 6.0f / 60.0f;
	m_CameraPos.y += 9.0f / 60.0f;
	m_CameraLook.x += 6.0f / 60.0f;
	m_CameraLook.y -= 0.3f / 60.0f;
	if (m_CameraLook.x <= 0.0f)
	{
		m_pCamera->SetPos(m_CameraPos.x, m_CameraPos.y, -5.0f);
		m_pCamera->Setlook(m_CameraLook.x, m_CameraLook.y, 0.0f);
	}

	DirectX::XMMATRIX world;
	//--- Geometory�p�̕ϊ��s����v�Z
	world =
		DirectX::XMMatrixScaling(m_Size.x, m_Size.y, m_Size.z)*
		DirectX::XMMatrixRotationX(m_rad.x) * DirectX::XMMatrixRotationY(m_rad.y) * DirectX::XMMatrixRotationZ(m_rad.z) *
		DirectX::XMMatrixTranslation(m_pos.x, m_pos.y, m_pos.z);
	world = DirectX::XMMatrixTranspose(world);	// �]�ڍs��ɕϊ�
	DirectX::XMStoreFloat4x4(&mat[0], world);	// XMMATRIX�^����XMFLOAT4x4�^(mat[0])�֕ϊ����Ċi�[
	mat[1] = m_pCamera->GetViewMatrix();
	mat[2] = m_pCamera->GetProjyectionMatrix();

	// �s����V�F�[�_�[�֐ݒ�
	m_pVS[0]->WriteBuffer(0, mat);
	m_pVS[1]->WriteBuffer(0, mat);
	m_pVS[2]->WriteBuffer(0, mat);
	m_pVS[3]->WriteBuffer(0, mat);

	//--- Geometory�p�̕ϊ��s���ݒ�
	Geometory::SetWorld(mat[0]);
	Geometory::SetView(mat[1]);
	Geometory::SetProjection(mat[2]);

	//Geometory::DrawBox();

	// ���f���\��
	switch (m_nKind)
	{
	case 1:
		if (m_pModel[0])
			m_pModel[0]->Draw();
		break;
	case 2:
		if (m_pModel[1])
			m_pModel[1]->Draw();
		break;
	case 3:
		if (m_pModel[2])
			m_pModel[2]->Draw();
		break;
	case 4:
		if (m_pModel[3])
			m_pModel[3]->Draw();
		break;
	default:
		break;
	}
}

DirectX::XMFLOAT3 StopBlockManager::GetPos()
{
	return m_pos;
}

DirectX::XMFLOAT3 StopBlockManager::GetSize()
{
	return m_Size;
}

void StopBlockManager::SetPos(DirectX::XMFLOAT3 pos)
{
	m_pos = pos;
}

