#ifndef __ITEM_UI_H__
#define __ITEM_UI_H__

#include "Texture.h"
#include "Sprite.h"

class ItemUI
{
public:
	ItemUI();
	~ItemUI();
	void Update();
	void DrawUI();
	void DrawStopTime();
	void DrawStopTime2();
	void DrawStopTime3();
	void DrawClear();

private:
	Texture* m_pTexture[5];
	DirectX::XMFLOAT4 m_UIAlpha;
	DirectX::XMFLOAT4 m_ClrUIAlpha;	// �N���AUI��p�̃��l

	float m_Alpha;	// ���l�X�V
};

#endif // __ITEM_UI_H__
