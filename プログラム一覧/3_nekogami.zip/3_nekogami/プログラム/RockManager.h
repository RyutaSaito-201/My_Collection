#ifndef ___ROCK_MNG_H___
#define ___ROCK_MNG_H___

#include <DirectXMath.h>
#include "Geometory.h"
#include "Model.h"
#include "Shader.h"
#include "CameraDebug.h"

class CRockManager
{
public:
	CRockManager();
	void CreateRock(float ScalingX, float ScalingY, float ScalingZ, float posX, float posY, float posZ);
	//virtual void Update() = 0;
	void Draw(DirectX::XMFLOAT4X4 mat[3]);

	void SetPos(DirectX::XMFLOAT3 rockpos);
	void SetOldPos(DirectX::XMFLOAT3 oldpos);
	void SetDirection(int nDirection, int i);
	int GetDirection(int i);

	DirectX::XMFLOAT3 GetPos();
	DirectX::XMFLOAT3 GetOldPos();
	DirectX::XMFLOAT3 GetSize();
	DirectX::XMFLOAT3 GetSizetoRock();

private:
	Model* m_pModel;
	VertexShader* m_pVS;
	CameraBase* m_pCamera;

	DirectX::XMFLOAT3 m_pos;		// ���S���W
	DirectX::XMFLOAT3 m_OldPos;
	DirectX::XMFLOAT3 m_Size;
	DirectX::XMFLOAT3 m_OldCenter;
	DirectX::XMFLOAT3 m_CollSize;	// �����蔻��p�̃T�C�Y
	DirectX::XMFLOAT3 m_CameraPos;
	DirectX::XMFLOAT3 m_CameraLook;

	int m_nPhase;	// �ǂ̃t�F�[�Y�Ŋ�𓮂�������
	int m_nDirection[3];	// �t�F�[�Y���ƂɃu���b�N����������������
};

#endif // !___ROCK_MNG_H___

