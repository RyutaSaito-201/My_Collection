#ifndef __Leaf_H__
#define __Leaf_H__

#include "Model.h"
#include "Shader.h"
#include <DirectXMath.h>


class Leaf
{
public:
	Leaf(DirectX::XMFLOAT3 pos);
	~Leaf();
	void Update();
	void Draw(DirectX::XMFLOAT4X4 mat[3]);
	DirectX::XMFLOAT3 GetPos();
	DirectX::XMFLOAT3 SetPos(DirectX::XMFLOAT3 pos);


private:
	Model* m_pModel;
	VertexShader* m_pVS;
	DirectX::XMFLOAT3 m_pos;
};

#endif

