#ifndef __Grass_H__
#define __Grass_H__

#include "Model.h"
#include "Shader.h"
#include <DirectXMath.h>


class Grass
{
public:
	Grass(DirectX::XMFLOAT3 pos);
	~Grass();
	void Update();
	void Draw(DirectX::XMFLOAT4X4 mat[3]);
	DirectX::XMFLOAT3 GetPos();
	DirectX::XMFLOAT3 SetPos(DirectX::XMFLOAT3 pos);


private:
	Model* m_pModel;
	VertexShader* m_pVS;
	DirectX::XMFLOAT3 m_pos;
};

#endif

