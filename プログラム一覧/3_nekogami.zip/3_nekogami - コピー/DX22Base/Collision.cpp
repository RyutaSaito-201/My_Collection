// ==�C���N���[�h��==
#include "Collision.h"

Collision::Collision()
{
}

Collision::~Collision()
{
}

void Collision::Update()
{



}

// AABB�̓����蔻��
bool Collision::AABBCollision(DirectX::XMFLOAT3 CenterPos1, DirectX::XMFLOAT3 CenterPos2, DirectX::XMFLOAT3 Size1, DirectX::XMFLOAT3 Size2)
{
	DirectX::XMFLOAT3 halfSize1;
	DirectX::XMFLOAT3 halfSize2;

	// ���a�����߂�
	halfSize1.x = Size1.x / 2.0f;
	halfSize1.y = Size1.y / 2.0f;
	halfSize1.z = Size1.z / 2.0f;
	halfSize2.x = Size2.x / 2.0f;
	halfSize2.y = Size2.y / 2.0f;
	halfSize2.z = Size2.z / 2.0f;

	if ((CenterPos1.x + halfSize1.x > CenterPos2.x - halfSize2.x) &&		// 1�̉E�� > 2�̍���
		(CenterPos2.x + halfSize2.x > CenterPos1.x - halfSize1.x))	// 2�̉E�� > 1�̍���
	{
		if ((CenterPos1.z + halfSize1.z > CenterPos2.z - halfSize2.z) &&		//1�̌��� > 2�̑O��
			(CenterPos2.z + halfSize2.z > CenterPos1.z - halfSize1.z))	//2�̌��� > 1�̑O��
		{
			if ((CenterPos1.y + halfSize1.y > CenterPos2.y - halfSize2.y) &&
				(CenterPos2.y + halfSize2.y > CenterPos1.y - halfSize1.y))
			{
				return true;
			}
		}
	}
	return false;
}





