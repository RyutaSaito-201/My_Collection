#ifndef __PLAYER_H__
#define __PLAYER_H__

// ==�C���N���[�h��==
#include "Time.h"
#include "DirectXMath.h"
#include "Geometory.h"
#include "Model.h"
#include "Shader.h"
#include "CameraDebug.h"
#include "LibEffekseer.h"

// ==�N���X==
class CPlayer
{
public:
	CPlayer();
	~CPlayer();
	void Update();
	void Draw();

	int GetDirection();	// �v���C���[�̌������Z�b�g

	void SetPos(DirectX::XMFLOAT3 playerpos);
	void SetCenter(DirectX::XMFLOAT3 playercenter);

	DirectX::XMFLOAT3 GetPos();
	DirectX::XMFLOAT3 GetOldPos();
	DirectX::XMFLOAT3 GetCenter();
	DirectX::XMFLOAT3 GetSize();
	DirectX::XMFLOAT3 GetOldCenter();

private:
	CTime* m_pTime;
	Model* m_pModel;
	VertexShader* m_pVS;
	CameraBase* m_pCamera;

	int m_nDirection;	// �v���C���[�̌����Ă������

	DirectX::XMFLOAT3 m_pos;
	DirectX::XMFLOAT3 m_OldPos;
	DirectX::XMFLOAT3 m_Center;
	DirectX::XMFLOAT3 m_Size;
	DirectX::XMFLOAT3 m_OldCenter;
	DirectX::XMFLOAT3 m_rad;
	DirectX::XMFLOAT3 m_CollSize;	// �����蔻��p�̃T�C�Y
	DirectX::XMFLOAT3 m_CameraPos;
	DirectX::XMFLOAT3 m_CameraLook;

	Effekseer::EffectRef effect;
	Effekseer::Handle efkHandle;

	int m_nCnt = 0;
};

#endif