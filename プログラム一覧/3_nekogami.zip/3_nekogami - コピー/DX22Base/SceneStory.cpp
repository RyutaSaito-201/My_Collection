#include "SceneStory.h"
#include "Input.h"
#include <Xinput.h>

//�ǂݍ��݃t�@�C��
#define STORY_PIC  ("Assets/Texture/Story.png")
#define STORY_PIC2 ("Assets/Texture/Story2.png")
#define STORY_PIC3 ("Assets/Texture/Story3.png")

#define STORY_WORD ("Assets/Texture/Story_word.png")
#define STORY_WORD2 ("Assets/Texture/Story_word2.png")
#define STORY_WORD3 ("Assets/Texture/Story_word3.png")

#define CONT_UI ("Assets/Texture/letter-a.png")

#define BGM_STORY()

#define MAX_TEXTURE (7)

XINPUT_STATE state5;

int j = 0;

SceneStory::SceneStory()
	: m_UIAlpha(1.0f, 1.0f, 1.0f, 1.0f)
	, m_BottonAlpha(0.0f, 0.0f, 0.0f, 0.0f)
	, m_pBGM(nullptr)
	, m_pBGMSpeaker(nullptr)
	, m_scene(SCENE_MAX)
	, m_size(2180.0f, -1520.0f)
	, m_pos(500.0f, 360.0f)
	, m_StoryPos(800.0f, 300.0f)
	, m_bMove(false)
	, m_frame(0)

{
	for (j = 0; j < MAX_TEXTURE; j++)
	{
		m_pTexture[j] = new Texture();
	}

	if (FAILED(m_pTexture[0]->Create(STORY_PIC)))
	{
		MessageBox(NULL, "SceneTitle Story.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[1]->Create(STORY_WORD)))
	{
		MessageBox(NULL, "SceneTitle Story_word.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[2]->Create(STORY_PIC2)))
	{
		MessageBox(NULL, "SceneTitle Story2.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[3]->Create(STORY_WORD2)))
	{
		MessageBox(NULL, "SceneTitle Story_word2.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[4]->Create(STORY_PIC3)))
	{
		MessageBox(NULL, "SceneTitle Story3.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[5]->Create(STORY_WORD3)))
	{
		MessageBox(NULL, "SceneTitle Story_word3.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[6]->Create(CONT_UI)))
	{
		MessageBox(NULL, "SceneTitle Letter-a.png", "Error", MB_OK);
	}

	//���f�ނ�
	m_pBGM = LoadSound("Assets/Sound/Decision.wav");

	/*m_pBGMSpeaker = PlaySound(m_pBGM);
	m_pBGMSpeaker->SetVolume(0.5f);*/
}

SceneStory::~SceneStory()
{
	for (j = 0; j < MAX_TEXTURE; j++)
	{
		if (m_pTexture[j])
		{
			delete m_pTexture[j];
			m_pTexture[j] = nullptr;
		}
	}
}

void SceneStory::Update(SceneManager * pSceneMng)
{
	if (m_pos.x < 750.0f)
	{
		m_pos.x += 0.7f;
	}

	if (m_pos.x > 748.0f)
	{
		m_bMove = true;
	}

	// �R���g���[���[���擾
	XInputGetState(0, &state5);
	if (IsKeyTrigger(VK_SPACE) || state5.Gamepad.wButtons & XINPUT_GAMEPAD_A)
	{
		if (SCENE_STORY)
		{
			m_pBGMSpeaker = PlaySound(m_pBGM);
			pSceneMng->SetNextScene(SCENE_STORY2);
			//m_pBGMSpeaker->Stop();
		}
		if (SCENE_STORY2)
		{
			m_pBGMSpeaker = PlaySound(m_pBGM);
 			pSceneMng->SetNextScene(SCENE_STORY3);
			//m_pBGMSpeaker->Stop();
		}
	}
}

void SceneStory::Update2(SceneManager * pSceneMng)
{
	if (m_StoryPos.x > 400.0f && m_StoryPos.y < 500.0f)
	{
		m_StoryPos.x -= 0.7f;
		m_StoryPos.y += 0.7f;
	}

	if (m_StoryPos.x > 410.0f && m_StoryPos.y < 490.0f)
	{

	}
	else
	{
		m_bMove = true;
	}

	// �R���g���[���[���擾
	XInputGetState(0, &state5);
	if (IsKeyTrigger(VK_SPACE) || state5.Gamepad.wButtons & XINPUT_GAMEPAD_A)
	{
		m_pBGMSpeaker = PlaySound(m_pBGM);
		pSceneMng->SetNextScene(SCENE_STORY3);
		//m_pBGMSpeaker->Stop();
	}
}

void SceneStory::Update3(SceneManager * pSceneMng)
{
	if (m_size.x > 1280.0f && m_size.y < -720.0f)
	{
		m_size.x -= 4.0f;
		m_size.y += 3.0f;
	}

	if (m_size.x > 1285.0f && m_size.y < -715.0f)
	{

	}
	else
	{
		m_bMove = true;
	}

	// �R���g���[���[���擾
	XInputGetState(0, &state5);
	if (IsKeyTrigger(VK_SPACE) || state5.Gamepad.wButtons & XINPUT_GAMEPAD_A)
	{
		m_pBGMSpeaker = PlaySound(m_pBGM);
		pSceneMng->SetNextScene(SCENE_SELECT);
		//m_pBGMSpeaker->Stop();
	}
}

void SceneStory::DrawStory()
{

	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			m_pos.x, m_pos.y, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(1580.0f, -1020.0f));
	Sprite::SetTexture(m_pTexture[0]);
	Sprite::Draw();
}

void SceneStory::DrawStory2()
{
	m_size.x = 1780.0f;
	m_size.y = -1220.0f;

	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			m_StoryPos.x, m_StoryPos.y, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(m_size.x, m_size.y));
	Sprite::SetTexture(m_pTexture[2]);
	Sprite::Draw();
}

void SceneStory::DrawStory3()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			640.0f, 360.0f, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(m_size.x, m_size.y));
	Sprite::SetTexture(m_pTexture[4]);
	Sprite::Draw();
}

void SceneStory::DrawLetter()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			640.0f, 680.0f, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(1280.0f, -100.0f));
	Sprite::SetTexture(m_pTexture[1]);
	Sprite::Draw();
}

void SceneStory::DrawLetter2()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			640.0f, 680.0f, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(1280.0f, -100.0f));
	Sprite::SetTexture(m_pTexture[3]);
	Sprite::Draw();
}

void SceneStory::DrawLetter3()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			640.0f, 680.0f, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(1280.0f, -100.0f));
	Sprite::SetTexture(m_pTexture[5]);
	Sprite::Draw();
}

void SceneStory::DrawButton()
{

	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			1200.0f, 680.0f, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_BottonAlpha);


	Sprite::SetSize(DirectX::XMFLOAT2(60.0f, -60.0f));
	Sprite::SetTexture(m_pTexture[6]);
	//Sprite::Draw();

	if (m_bMove == true)
	{
		//�o�ߎ��Ԃɕ����ă��l�̕ύX
		float totalTime = 2.0f;	//1�T�ɂ����鎞��
		int totalFrame = totalTime * 60;	//1�T�ɂ�����t���[��
		//���v�t���[���ɑ΂��錻�݂̌o�ߊ���
		float rate = (float)m_frame / totalFrame;
		m_BottonAlpha.w = sinf(2.0f * 3.1415f * rate);
		m_BottonAlpha.x = sinf(2.0f * 3.1415f * rate);
		m_BottonAlpha.y = sinf(2.0f * 3.1415f * rate);
		m_BottonAlpha.z = sinf(2.0f * 3.1415f * rate);
		//sin�̒l��-1�`1�Ȃ̂�0�`1�ɕϊ�
		m_BottonAlpha.w = (m_BottonAlpha.w + 1.0f) * 0.5f;
		m_BottonAlpha.x = (m_BottonAlpha.x + 1.0f) * 0.5f;
		m_BottonAlpha.y = (m_BottonAlpha.y + 1.0f) * 0.5f;
		m_BottonAlpha.z = (m_BottonAlpha.z + 1.0f) * 0.5f;


		//�o�ߎ��Ԃ̃J�E���g
		m_frame++;
		Sprite::Draw();
		m_bMove = false;
	}
}
