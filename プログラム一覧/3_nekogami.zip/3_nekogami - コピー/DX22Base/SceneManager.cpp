#include "SceneManager.h"
#include "SceneGame.h"
#include "SceneTitle.h"
#include "SceneStory.h"
#include "SceneSelect.h"
#include "Fade.h"

//�����ɉ�(BGM)�����āI


SceneManager::SceneManager()
	:m_scene(SCENE_MAX)
	,m_nextScene(SCENE_TITLE)
	,m_pGame(nullptr)
	,m_pFade(nullptr)
	,m_fadetime(false)
	,m_pTitle(nullptr)
	,m_pStory(nullptr)
	,m_pSelect(nullptr)
{
	m_pFade = new Fade();
}

SceneManager::~SceneManager()
{
	switch (m_scene)
	{
	case SCENE_TITLE:
		delete m_pTitle;
		break;
	case SCENE_SELECT:
		delete m_pSelect;
		break;
	case SCENE_STORY:
		delete m_pStory;
		break;
	case SCENE_STORY2:
		delete m_pStory;
		break;
	case SCENE_STORY3:
		delete m_pStory;
		break;
	case SCENE_GAME:
		delete m_pGame;
		break;
	case SCENE_RESTART:
		delete m_pGame;
		break;
	default:
		break;

	}
	delete m_pFade;
}

void SceneManager::Update(float tick)
{
	if (!m_pFade->IsPlay())
	{
		//�V�[���؂�ւ�����
		if (m_scene != m_nextScene)
		{
			//���݂̃V�[���̏I��
			switch (m_scene)
			{
			case SCENE_TITLE:
				delete m_pTitle;
				break;
			case SCENE_SELECT:
				delete m_pSelect;
				break;
			case SCENE_STORY:
				delete m_pStory;
				break;
			case SCENE_STORY2:
				delete m_pStory;
				break;
			case SCENE_STORY3:
				delete m_pStory;
				break;
			case SCENE_GAME:
				delete m_pGame;
				break;
			case SCENE_RESTART:
				delete m_pGame;
				break;
			default:
				break;
			}

			//������BGM�̍Đ���~������


			//�V�����V�[���̓ǂݍ���
			switch (m_nextScene)
			{
			case SCENE_TITLE:
				m_pTitle = new SceneTitle();
				break;
			case SCENE_SELECT:
				m_pSelect = new SceneSelect();
				break;
			case SCENE_STORY:
				m_pStory = new SceneStory();
				break;
			case SCENE_STORY2:
				m_pStory = new SceneStory();
				break;
			case SCENE_STORY3:
				m_pStory = new SceneStory();
				break;
			case SCENE_GAME:
				m_pGame = new SceneGame();
				break;
			case SCENE_RESTART:
				m_pGame = new SceneGame();
				break;
			default:
				break;
			}

			//���݂̃V�[����V�����V�[���֏㏑��
			m_scene = m_nextScene;

			//�t�F�[�h�C��
			m_pFade->Start(true, 1.0f);

			//BGM���Đ����鏈���͂�����
		}
	}
	else
	{

	}

	//�V�[���X�V����
	switch (m_scene)
	{
	case SCENE_TITLE:
		if (!m_fadetime)
		{
			m_pTitle->Update(this);
		}
		break;
	case SCENE_SELECT:
		m_pSelect->Update(this);
		break;
	case SCENE_STORY:
		m_pStory->Update(this);
		break;
	case SCENE_STORY2:
		m_pStory->Update2(this);
		break;
	case SCENE_STORY3:
		m_pStory->Update3(this);
		break;
	case SCENE_GAME:
		m_pGame->Update(tick, this);
		break;
	case SCENE_RESTART:
		m_pGame->Update(tick, this);
		break;
	default:
		break;
	}

	m_fadetime = m_pFade->IsPlay();

	//�t�F�[�h�̍X�V����
	m_pFade->Update();


}

void SceneManager::Draw()
{
	switch (m_scene)
	{
	case SCENE_TITLE:
		m_pTitle->DrawBack();
		m_pTitle->DrawBack2();
		m_pTitle->Draw();
		m_pTitle->DrawStart();
		break;
	case SCENE_SELECT:
		m_pSelect->Draw();
		break;
	case SCENE_STORY:
		m_pStory->DrawStory();
		m_pStory->DrawLetter();
		m_pStory->DrawButton();
		break;
	case SCENE_STORY2:
		m_pStory->DrawStory2();
		m_pStory->DrawLetter2();
		m_pStory->DrawButton();
		break;
	case SCENE_STORY3:
		m_pStory->DrawStory3();
		m_pStory->DrawLetter3();
		m_pStory->DrawButton();
		break;
	case SCENE_GAME:
		m_pGame->Draw(this);
		break;
	case SCENE_RESTART:
		m_pGame->Draw(this);
		break;
	default:
		break;
	}

	//��ԍŌ�ɉ�ʑS�̂ɕ\������
	m_pFade->Draw();
}

void SceneManager::SetNextScene(SceneKind scene)
{
	//�t�F�[�h���͎��̃V�[����\�񂵂Ȃ��悤��
	if (m_pFade->IsPlay())
	{
		return;
	}
	m_nextScene = scene;
	m_pFade->Start(false, 1.0f);
}

int SceneManager::GetCurrentScene()
{
	return m_scene;
}

bool SceneManager::GetFadetime()
{
	return m_fadetime;
}
