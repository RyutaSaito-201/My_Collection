#include "SelectPlayer.h"

// ==�O���[�o���ϐ�==
//XINPUT_STATE selectstate;

// ==�萔��`==
#define PLAYER_MOVE (2.0f)


SelectPlayer::SelectPlayer()
	:m_pos(640.0f, 620.0f, 0.0f)
	,m_alpha(1.0f, 1.0f, 1.0f, 1.0f)
	,m_size(200.0f, -200.0f)
	,m_UVPos(1.0f, 1.0f)
	,m_UVScale(1.0f, 1.0f)
{
	m_pTexture = new Texture();
	//�v���C���[�̃e�N�X�`���ǂݍ���
	if (FAILED(m_pTexture->Create("Assets/Texture/cat.png")))
	{
		MessageBox(NULL, "Sceneselect.Player", "Error", MB_OK);
	}

}

SelectPlayer::~SelectPlayer()
{
	if (m_pTexture)
	{
		delete m_pTexture;
		m_pTexture = nullptr;
	}

}

void SelectPlayer::Update()
{
	//XInputGetState(0, &selectstate);

	//if (selectstate.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT || IsKeyPress('A'))
	//{
	//	m_pos.x -= PLAYER_MOVE;
	//}

	//if (selectstate.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT || IsKeyPress('D'))
	//{
	//	m_pos.x += PLAYER_MOVE;
	//}

	if (IsKeyPress('A'))
	{
		m_pos.x -= PLAYER_MOVE;
	}
	if (IsKeyPress('D'))
	{
		m_pos.x += PLAYER_MOVE;
	}


}

void SelectPlayer::Draw()
{
	//--�v���C���[�`��
	DirectX::XMFLOAT4X4 mat[3];
	//�e�N�X�`���̕`��ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(m_pos.x, m_pos.y, m_pos.z);

	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);

	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVPos({ m_UVPos.x, m_UVPos.y });
	Sprite::SetUVScale({ m_UVScale.x, m_UVScale.y });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_alpha);
	Sprite::SetSize(DirectX::XMFLOAT2(m_size.x, m_size.y));	//1280.-720
	Sprite::SetTexture(m_pTexture);
	Sprite::Draw();

}

DirectX::XMFLOAT3 SelectPlayer::GetPos()
{
	return m_pos;
}

DirectX::XMFLOAT2 SelectPlayer::GetSize()
{
	return m_size;
}
