#ifndef __SELECT_PLAYER_H__
#define __SELECT_PLAYER_H__

#include "Input.h"
#include <Xinput.h>
#include "Model.h"
#include "Texture.h"
#include "Sprite.h"
#include "CameraSelect.h"
//#include "CameraSelectBase.h"
#include "Geometory.h"


class SelectPlayer
{
public:
	SelectPlayer();
	~SelectPlayer();
	void Update();
	void Draw();

	DirectX::XMFLOAT3 GetPos();
	DirectX::XMFLOAT2 GetSize();
private:
	DirectX::XMFLOAT4 m_alpha;
	DirectX::XMFLOAT3 m_pos;
	DirectX::XMFLOAT2 m_size;
	DirectX::XMFLOAT2 m_UVPos;
	DirectX::XMFLOAT2 m_UVScale;
	Texture* m_pTexture;
	Model* m_pModel;
	VertexShader* m_pVS;
	CameraSelect* m_pCamera;
};



#endif // !__SELECT_PLAYER_H__

