//TitleScene.h
#ifndef _SCENE_TITLE_H_
#define _SCENE_TITLE_H_

#include "Texture.h"
#include "Sprite.h"
#include "SceneManager.h"
#include "Sound.h"
#include "EffectMng.h"
#include "CameraBase.h"

class SceneTitle
{
public:
	SceneTitle();
	~SceneTitle();
	void Update(SceneManager* pSceneMng);
	void Draw();
	void DrawStart();
	void DrawBack();
	void DrawBack2();

private:
	Texture* m_pTexture[7];
	DirectX::XMFLOAT4 m_UIAlpha;
	DirectX::XMFLOAT3 m_BackPos;
	DirectX::XMFLOAT3 m_BackPos2;
	DirectX::XMFLOAT2 m_BackSize;

	bool m_bTrigger;

	XAUDIO2_BUFFER* m_pBGM;
	IXAudio2SourceVoice* m_pBGMSpeaker;

	EffectMng* m_pEffectMng;
	int m_nframe;		// �G�t�F�N�g�̍Đ����x
	int m_nAnimeNo;		// �G�t�F�N�g�̃R�}�Ǘ��p
	bool m_bAnimeNo;
	CameraBase* m_pCamera;
};

#endif // _SCENE_TITLE_H_