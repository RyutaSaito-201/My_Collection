#include "ArrowEffect.h"

ArrowEffect::ArrowEffect()
{
	if (FAILED(m_pEffectMng[0] = new EffectMng("Assets/Texture/greenUp.png")))
	{
		//MessageBox(NULL, "hit1.png", "Error", MB_OK);
	}

	m_pEffectMng[0] = new EffectMng("Assets/Texture/greenUp.png");
	m_pEffectMng[1] = new EffectMng("Assets/Texture/greenDown.png");
	m_pEffectMng[2] = new EffectMng("Assets/Texture/greenRight.png");
	m_pEffectMng[3] = new EffectMng("Assets/Texture/greenLeft.png");
	m_pEffectMng[4] = new EffectMng("Assets/Texture/yellowUp.png");
	m_pEffectMng[5] = new EffectMng("Assets/Texture/yellowDown.png");
	m_pEffectMng[6] = new EffectMng("Assets/Texture/yellowRight.png");
	m_pEffectMng[7] = new EffectMng("Assets/Texture/yellowLeft.png");
	m_pEffectMng[8] = new EffectMng("Assets/Texture/redUp.png");
	m_pEffectMng[9] = new EffectMng("Assets/Texture/redDown.png");
	m_pEffectMng[10] = new EffectMng("Assets/Texture/redRight.png");
	m_pEffectMng[11] = new EffectMng("Assets/Texture/redLeft.png");
	m_pEffectMng[12] = new EffectMng("Assets/Texture/greenUp.png");
	m_pEffectMng[13] = new EffectMng("Assets/Texture/greenDown.png");
	m_pEffectMng[14] = new EffectMng("Assets/Texture/greenRight.png");
	m_pEffectMng[15] = new EffectMng("Assets/Texture/greenLeft.png");
	m_pEffectMng[16] = new EffectMng("Assets/Texture/yellowUp.png");
	m_pEffectMng[17] = new EffectMng("Assets/Texture/yellowDown.png");
	m_pEffectMng[18] = new EffectMng("Assets/Texture/yellowRight.png");
	m_pEffectMng[19] = new EffectMng("Assets/Texture/yellowLeft.png");
	m_pEffectMng[20] = new EffectMng("Assets/Texture/redUp.png");
	m_pEffectMng[21] = new EffectMng("Assets/Texture/redDown.png");
	m_pEffectMng[22] = new EffectMng("Assets/Texture/redRight.png");
	m_pEffectMng[23] = new EffectMng("Assets/Texture/redLeft.png");
	m_pEffectMng[24] = new EffectMng("Assets/Texture/greenUp.png");
	m_pEffectMng[25] = new EffectMng("Assets/Texture/greenDown.png");
	m_pEffectMng[26] = new EffectMng("Assets/Texture/greenRight.png");
	m_pEffectMng[27] = new EffectMng("Assets/Texture/greenLeft.png");
	m_pEffectMng[28] = new EffectMng("Assets/Texture/yellowUp.png");
	m_pEffectMng[29] = new EffectMng("Assets/Texture/yellowDown.png");
	m_pEffectMng[30] = new EffectMng("Assets/Texture/yellowRight.png");
	m_pEffectMng[31] = new EffectMng("Assets/Texture/yellowLeft.png");
	m_pEffectMng[32] = new EffectMng("Assets/Texture/redUp.png");
	m_pEffectMng[33] = new EffectMng("Assets/Texture/redDown.png");
	m_pEffectMng[34] = new EffectMng("Assets/Texture/redRight.png");
	m_pEffectMng[35] = new EffectMng("Assets/Texture/redLeft.png");

	// ���\���p�̃J�����̐���
	m_pCamera = new CameraDebug();

	// �J�������W�̐ݒ�
	m_pCamera->SetUp(0.0f, 0.0f, 1.0f);

	for (int i = 0; i < ARROW_EFFECT_MAX; i++)
	{
		m_bIsEffect[i] = false;
		m_bIsPlay[i] = true;
		m_nAnimeNo[i] = 0;
		m_nframe[i] = 0;
	}

}

ArrowEffect::~ArrowEffect()
{

}

void ArrowEffect::Update(int Direction, int Phase, DirectX::XMFLOAT3 Pos[3], DirectX::XMFLOAT3 RockPos, bool IsEffect)
{
	m_pos[0] = Pos[0];
	m_pos[1] = Pos[1];
	m_pos[2] = Pos[2];

	// === �u���b�N1 ===
	if (m_pos[0].x == RockPos.x &&
		m_pos[0].z == RockPos.z)
	{
		switch (Phase)
		{
		case 1:
			switch (Direction)
			{
			case 1:	// ��
				if (m_bIsEffect[1] || m_bIsEffect[2] || m_bIsEffect[3])
				{
					for (int i = 1; i < 4; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[0])
				{
					m_bIsPlay[0] = false;
					m_bIsEffect[0] = IsEffect;
				}
				if (m_bIsEffect[0])
				{
					if (m_nframe[0] >= 10)
					{
						m_nframe[0] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[0]++;
						if (m_nAnimeNo[0] >= 30)
						{

							m_nAnimeNo[0] = 29;

						}
					}
					m_pEffectMng[0]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[0], { m_pos[0].x, m_pos[0].y + 2.0f, m_pos[0].z + 1.0f }, 8);
					m_nframe[0]++;
				}
				break;
			case 2:	// ��
				if (m_bIsEffect[0] || m_bIsEffect[2] || m_bIsEffect[3])
				{
					m_bIsEffect[0] = false;
					m_bIsPlay[0] = true;
					m_nAnimeNo[0] = 0;

					for (int i = 2; i < 4; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}


				if (m_bIsPlay[1])
				{
					m_bIsPlay[1] = false;
					m_bIsEffect[1] = IsEffect;
				}
				if (m_bIsEffect[1])
				{
					if (m_nframe[1] >= 10)
					{
						m_nframe[1] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[1]++;
						if (m_nAnimeNo[1] >= 29)
						{
							m_nAnimeNo[1] = 28;
							
						}
					}
					m_pEffectMng[1]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[1], { m_pos[0].x, m_pos[0].y + 2.0f, m_pos[0].z - 1.0f }, 8);
					m_nframe[1]++;
				}
				break;
			case 3: // �E

				if (m_bIsEffect[0] || m_bIsEffect[1] || m_bIsEffect[3])
				{
					m_bIsEffect[3] = false;
					m_bIsPlay[3] = true;
					m_nAnimeNo[3] = 0;

					for (int i = 0; i < 2; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[2])
				{
					m_bIsPlay[2] = false;
					m_bIsEffect[2] = IsEffect;
				}
				if (m_bIsEffect[2])
				{
					if (m_nframe[2] >= 10)
					{
						m_nframe[2] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[2]++;
						if (m_nAnimeNo[2] >= 30)
						{
							m_nAnimeNo[2] = 29;
						}
					}
					m_pEffectMng[2]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[2], { m_pos[0].x + 2.0f, m_pos[0].y + 2.0f, m_pos[0].z - 1.0f }, 8);
					m_nframe[2]++;
				}
				break;
			case 4: // ��

				if (m_bIsEffect[0] || m_bIsEffect[1] || m_bIsEffect[2])
				{

					for (int i = 0; i < 3; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[3])
				{
					m_bIsPlay[3] = false;
					m_bIsEffect[3] = IsEffect;
				}
				if (m_bIsEffect[3])
				{
					if (m_nframe[3] >= 10)
					{
						m_nframe[3] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[3]++;
						if (m_nAnimeNo[3] >= 29)
						{
							m_nAnimeNo[3] = 28;
						}
					}
					m_pEffectMng[3]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[3], { m_pos[0].x - 2.0f, m_pos[0].y + 2.0f, m_pos[0].z - 1.0f }, 8);
					m_nframe[3]++;
				}
				break;
			default:
				break;
			}
			break;
		case 2:
			switch (Direction)
			{
			case 1:	// ��

				if (m_bIsEffect[5] || m_bIsEffect[6] || m_bIsEffect[7])
				{
					for (int i = 5; i < 8; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[4])
				{
					m_bIsPlay[4] = false;
					m_bIsEffect[4] = IsEffect;
				}
				if (m_bIsEffect[4])
				{
					if (m_nframe[4] >= 10)
					{
						m_nframe[4] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[4]++;
						if (m_nAnimeNo[4] >= 30)
						{
							m_nAnimeNo[4] = 29;
						}
					}
					m_pEffectMng[4]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[4], { m_pos[0].x, m_pos[0].y + 2.0f, m_pos[0].z + 1.0f }, 8);
					m_nframe[4]++;
				}
				break;
			case 2:	// ��

				if (m_bIsEffect[4] || m_bIsEffect[6] || m_bIsEffect[7])
				{
					m_bIsEffect[4] = false;
					m_bIsPlay[4] = true;
					m_nAnimeNo[4] = 0;

					for (int i = 6; i < 8; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[5])
				{
					m_bIsPlay[5] = false;
					m_bIsEffect[5] = IsEffect;
				}
				if (m_bIsEffect[5])
				{
					if (m_nframe[5] >= 10)
					{
						m_nframe[5] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[5]++;
						if (m_nAnimeNo[5] >= 29)
						{
							m_nAnimeNo[5] = 28;
						}
					}
					m_pEffectMng[5]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[5], { m_pos[0].x, m_pos[0].y + 2.0f, m_pos[0].z - 1.0f }, 8);
					m_nframe[5]++;
				}
				break;
			case 3: // �E

				if (m_bIsEffect[4] || m_bIsEffect[5] || m_bIsEffect[7])
				{
					m_bIsEffect[7] = false;
					m_bIsPlay[7] = true;
					m_nAnimeNo[7] = 0;

					for (int i = 4; i < 6; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[6])
				{
					m_bIsPlay[6] = false;
					m_bIsEffect[6] = IsEffect;
				}
				if (m_bIsEffect[6])
				{
					if (m_nframe[6] >= 10)
					{
						m_nframe[6] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[6]++;
						if (m_nAnimeNo[6] >= 30)
						{
							m_nAnimeNo[6] = 29;
						}
					}
					m_pEffectMng[6]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[6], { m_pos[0].x + 2.0f, m_pos[0].y + 2.0f, m_pos[0].z - 1.0f }, 8);
					m_nframe[6]++;
				}
				break;
			case 4: // ��

				if (m_bIsEffect[4] || m_bIsEffect[5] || m_bIsEffect[6])
				{
					for (int i = 4; i < 7; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[7])
				{
					m_bIsPlay[7] = false;
					m_bIsEffect[7] = IsEffect;
				}
				if (m_bIsEffect[7])
				{
					if (m_nframe[7] >= 10)
					{
						m_nframe[7] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[7]++;
						if (m_nAnimeNo[7] >= 29)
						{
							m_nAnimeNo[7] = 28;
						}
					}
					m_pEffectMng[7]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[7], { m_pos[0].x - 2.0f, m_pos[0].y + 2.0f , m_pos[0].z - 1.0f }, 8);
					m_nframe[7]++;
				}
				break;
			default:
				break;
			}
			break;
		case 3:
			switch (Direction)
			{
			case 1:	// ��

				if (m_bIsEffect[9] || m_bIsEffect[10] || m_bIsEffect[11])
				{

					for (int i = 9; i < 12; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[8])
				{
					m_bIsPlay[8] = false;
					m_bIsEffect[8] = IsEffect;
				}
				if (m_bIsEffect[8])
				{
					if (m_nframe[8] >= 10)
					{
						m_nframe[8] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[8]++;
						if (m_nAnimeNo[8] >= 30)
						{
							m_nAnimeNo[8] = 29;
						}
					}
					m_pEffectMng[8]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[8], { m_pos[0].x, m_pos[0].y + 2.0f, m_pos[0].z + 1.0f }, 8);
					m_nframe[8]++;
				}
				break;
			case 2:	// ��
				if (m_bIsEffect[8] || m_bIsEffect[10] || m_bIsEffect[11])
				{
					m_bIsEffect[8] = false;
					m_bIsPlay[8] = true;
					m_nAnimeNo[8] = 0;

					for (int i = 10; i < 12; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[9])
				{
					m_bIsPlay[9] = false;
					m_bIsEffect[9] = IsEffect;
				}
				if (m_bIsEffect[9])
				{
					if (m_nframe[9] >= 10)
					{
						m_nframe[9] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[9]++;
						if (m_nAnimeNo[9] >= 29)
						{
							m_nAnimeNo[9] = 28;
						}
					}
					m_pEffectMng[9]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[9], { m_pos[0].x, m_pos[0].y + 2.0f, m_pos[0].z - 1.0f }, 8);
					m_nframe[9]++;
				}
				break;
			case 3: // �E

				if (m_bIsEffect[8] || m_bIsEffect[9] || m_bIsEffect[11])
				{
					m_bIsEffect[11] = false;
					m_bIsPlay[11] = true;
					m_nAnimeNo[11] = 0;

					for (int i = 8; i < 10; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[10])
				{
					m_bIsPlay[10] = false;
					m_bIsEffect[10] = IsEffect;
				}
				if (m_bIsEffect[10])
				{
					if (m_nframe[10] >= 10)
					{
						m_nframe[10] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[10]++;
						if (m_nAnimeNo[10] >= 29)
						{
							m_nAnimeNo[10] = 28;
						}
					}
					m_pEffectMng[10]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[10], { m_pos[0].x + 2.0f, m_pos[0].y + 2.0f, m_pos[0].z - 1.0f }, 8);
					m_nframe[10]++;
				}
				break;
			case 4: // ��

				if (m_bIsEffect[8] || m_bIsEffect[9] || m_bIsEffect[10])
				{

					for (int i = 8; i < 11; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[11])
				{
					m_bIsPlay[11] = false;
					m_bIsEffect[11] = IsEffect;
				}
				if (m_bIsEffect[11])
				{
					if (m_nframe[11] >= 10)
					{
						m_nframe[11] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[11]++;
						if (m_nAnimeNo[11] >= 29)
						{
							m_nAnimeNo[11] = 28;
						}
					}
					m_pEffectMng[11]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[11], { m_pos[0].x - 2.0f, m_pos[0].y + 2.0f, m_pos[0].z - 1.0f }, 8);
					m_nframe[11]++;
				}
				break;
			default:
				break;
			}

		default:
			break;
		}
	}

	// === �u���b�N2 ===
	if (m_pos[1].x == RockPos.x &&
		m_pos[1].z == RockPos.z)
	{
		switch (Phase)
		{
		case 1:
			switch (Direction)
			{
			case 1:	// ��
				if (m_bIsEffect[13] || m_bIsEffect[14] || m_bIsEffect[15])
				{
					for (int i = 13; i < 16; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[12])
				{
					m_bIsPlay[12] = false;
					m_bIsEffect[12] = IsEffect;
				}
				if (m_bIsEffect[12])
				{
					if (m_nframe[12] >= 10)
					{
						m_nframe[12] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[12]++;
						if (m_nAnimeNo[12] >= 30)
						{

							m_nAnimeNo[12] = 29;

							//m_bIsEffect[0] = false; 
							//m_bIsPlay[0] = true;
						}
					}
					m_pEffectMng[12]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[12], { m_pos[1].x, m_pos[1].y + 2.0f, m_pos[1].z + 1.0f }, 8);
					m_nframe[12]++;
				}
				break;
			case 2:	// ��
				if (m_bIsEffect[12] || m_bIsEffect[14] || m_bIsEffect[15])
				{
					m_bIsEffect[12] = false;
					m_bIsPlay[12] = true;
					m_nAnimeNo[12] = 0;

					for (int i = 14; i < 15; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}


				if (m_bIsPlay[13])
				{
					m_bIsPlay[13] = false;
					m_bIsEffect[13] = IsEffect;
				}
				if (m_bIsEffect[13])
				{
					if (m_nframe[13] >= 10)
					{
						m_nframe[13] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[13]++;
						if (m_nAnimeNo[13] >= 29)
						{
							m_nAnimeNo[13] = 28;
							//m_bIsEffect[13] = false;
							//m_bIsPlay[13] = true;
						}
					}
					m_pEffectMng[13]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[13], { m_pos[1].x, m_pos[1].y + 2.0f, m_pos[1].z - 2.0f }, 8);
					m_nframe[13]++;
				}
				break;
			case 3: // �E

				if (m_bIsEffect[12] || m_bIsEffect[13] || m_bIsEffect[15])
				{
					m_bIsEffect[15] = false;
					m_bIsPlay[15] = true;
					m_nAnimeNo[15] = 0;

					for (int i = 12; i < 15; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[14])
				{
					m_bIsPlay[14] = false;
					m_bIsEffect[14] = IsEffect;
				}
				if (m_bIsEffect[14])
				{
					if (m_nframe[14] >= 10)
					{
						m_nframe[14] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[14]++;
						if (m_nAnimeNo[14] >= 30)
						{
							m_nAnimeNo[14] = 29;
						}
					}
					m_pEffectMng[14]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[14], { m_pos[1].x + 2.0f, m_pos[1].y + 2.0f, m_pos[1].z - 0.75f }, 8);
					m_nframe[14]++;
				}
				break;
			case 4: // ��

				if (m_bIsEffect[12] || m_bIsEffect[13] || m_bIsEffect[14])
				{

					for (int i = 0; i < 3; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[15])
				{
					m_bIsPlay[15] = false;
					m_bIsEffect[15] = IsEffect;
				}
				if (m_bIsEffect[15])
				{
					if (m_nframe[15] >= 10)
					{
						m_nframe[15] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[15]++;
						if (m_nAnimeNo[15] >= 29)
						{
							m_nAnimeNo[15] = 28;
						}
					}
					m_pEffectMng[15]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[15], { m_pos[1].x - 2.0f, m_pos[1].y + 2.0f, m_pos[1].z - 0.75f }, 8);
					m_nframe[15]++;
				}
				break;
			default:
				break;
			}
			break;
		case 2:
			switch (Direction)
			{
			case 1:	// ��

				if (m_bIsEffect[17] || m_bIsEffect[18] || m_bIsEffect[19])
				{
					for (int i = 17; i < 19; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[16])
				{
					m_bIsPlay[16] = false;
					m_bIsEffect[16] = IsEffect;
				}
				if (m_bIsEffect[16])
				{
					if (m_nframe[16] >= 10)
					{
						m_nframe[16] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[16]++;
						if (m_nAnimeNo[16] >= 30)
						{
							m_nAnimeNo[16] = 29;
						}
					}
					m_pEffectMng[16]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[16], { m_pos[1].x, m_pos[1].y + 2.0f, m_pos[1].z + 1.0f }, 8);
					m_nframe[16]++;
				}
				break;
			case 2:	// ��

				if (m_bIsEffect[16] || m_bIsEffect[18] || m_bIsEffect[19])
				{
					m_bIsEffect[16] = false;
					m_bIsPlay[16] = true;
					m_nAnimeNo[16] = 0;

					for (int i = 18; i < 20; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[17])
				{
					m_bIsPlay[17] = false;
					m_bIsEffect[17] = IsEffect;
				}
				if (m_bIsEffect[17])
				{
					if (m_nframe[17] >= 10)
					{
						m_nframe[17] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[17]++;
						if (m_nAnimeNo[17] >= 29)
						{
							m_nAnimeNo[17] = 28;
						}
					}
					m_pEffectMng[17]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[17], { m_pos[1].x, m_pos[1].y + 2.0f, m_pos[1].z - 2.0f }, 8);
					m_nframe[17]++;
				}
				break;
			case 3: // �E

				if (m_bIsEffect[16] || m_bIsEffect[17] || m_bIsEffect[19])
				{
					m_bIsEffect[19] = false;
					m_bIsPlay[19] = true;
					m_nAnimeNo[19] = 0;

					for (int i = 16; i < 18; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}


				if (m_bIsPlay[18])
				{
					m_bIsPlay[18] = false;
					m_bIsEffect[18] = IsEffect;
				}
				if (m_bIsEffect[18])
				{
					if (m_nframe[18] >= 10)
					{
						m_nframe[18] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[18]++;
						if (m_nAnimeNo[18] >= 30)
						{
							m_nAnimeNo[18] = 29;
						}
					}
					m_pEffectMng[18]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[18], { m_pos[1].x + 2.0f, m_pos[1].y + 2.0f, m_pos[1].z - 0.75f }, 8);
					m_nframe[18]++;
				}
				break;
			case 4: // ��

				if (m_bIsEffect[16] || m_bIsEffect[17] || m_bIsEffect[18])
				{
					for (int i = 16; i < 18; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[19])
				{
					m_bIsPlay[19] = false;
					m_bIsEffect[19] = IsEffect;
				}
				if (m_bIsEffect[19])
				{
					if (m_nframe[19] >= 10)
					{
						m_nframe[19] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[19]++;
						if (m_nAnimeNo[19] >= 29)
						{
							m_nAnimeNo[19] = 28;
						}
					}
					m_pEffectMng[19]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[19], { m_pos[1].x - 2.0f, m_pos[1].y + 2.0f , m_pos[1].z - 0.75f }, 8);
					m_nframe[19]++;
				}
				break;
			default:
				break;
			}
			break;
		case 3:
			switch (Direction)
			{
			case 1:	// ��

				if (m_bIsEffect[21] || m_bIsEffect[22] || m_bIsEffect[23])
				{

					for (int i = 21; i < 24; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[20])
				{
					m_bIsPlay[20] = false;
					m_bIsEffect[20] = IsEffect;
				}
				if (m_bIsEffect[20])
				{
					if (m_nframe[20] >= 10)
					{
						m_nframe[20] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[20]++;
						if (m_nAnimeNo[20] >= 30)
						{
							m_nAnimeNo[20] = 29;
						}
					}
					m_pEffectMng[20]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[20], { m_pos[1].x, m_pos[1].y + 2.0f, m_pos[1].z + 1.0f }, 8);
					m_nframe[20]++;
				}
				break;
			case 2:	// ��
				if (m_bIsEffect[20] || m_bIsEffect[22] || m_bIsEffect[23])
				{
					m_bIsEffect[20] = false;
					m_bIsPlay[20] = true;
					m_nAnimeNo[20] = 0;

					for (int i = 22; i < 24; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[21])
				{
					m_bIsPlay[21] = false;
					m_bIsEffect[21] = IsEffect;
				}
				if (m_bIsEffect[21])
				{
					if (m_nframe[21] >= 10)
					{
						m_nframe[21] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[21]++;
						if (m_nAnimeNo[21] >= 29)
						{
							m_nAnimeNo[21] = 28;
						}
					}
					m_pEffectMng[21]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[21], { m_pos[1].x, m_pos[1].y + 2.0f, m_pos[1].z - 1.0f }, 8);
					m_nframe[21]++;
				}
				break;
			case 3: // �E

				if (m_bIsEffect[20] || m_bIsEffect[21] || m_bIsEffect[23])
				{
					m_bIsEffect[23] = false;
					m_bIsPlay[23] = true;
					m_nAnimeNo[23] = 0;

					for (int i = 20; i < 22; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[22])
				{
					m_bIsPlay[22] = false;
					m_bIsEffect[22] = IsEffect;
				}
				if (m_bIsEffect[22])
				{
					if (m_nframe[22] >= 10)
					{
						m_nframe[22] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[22]++;
						if (m_nAnimeNo[22] >= 30)
						{
							m_nAnimeNo[22] = 29;
						}
					}
					m_pEffectMng[22]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[22], { m_pos[1].x + 2.0f, m_pos[1].y + 2.0f, m_pos[1].z - 0.75f }, 8);
					m_nframe[22]++;
				}
				break;
			case 4: // ��

				if (m_bIsEffect[20] || m_bIsEffect[21] || m_bIsEffect[22])
				{

					for (int i = 20; i < 23; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[23])
				{
					m_bIsPlay[23] = false;
					m_bIsEffect[23] = IsEffect;
				}
				if (m_bIsEffect[23])
				{
					if (m_nframe[23] >= 10)
					{
						m_nframe[23] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[23]++;
						if (m_nAnimeNo[23] >= 29)
						{
							m_nAnimeNo[23] = 28;
						}
					}
					m_pEffectMng[23]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[23], { m_pos[1].x - 2.0f, m_pos[1].y + 2.0f, m_pos[1].z - 0.75f }, 8);
					m_nframe[23]++;
				}
				break;
			default:
				break;
			}

		default:
			break;
		}
	}

	// === �u���b�N3 ===
	if (m_pos[2].x == RockPos.x &&
		m_pos[2].z == RockPos.z)
	{
		switch (Phase)
		{
		case 1:
			switch (Direction)
			{
			case 1:	// ��
				if (m_bIsEffect[25] || m_bIsEffect[26] || m_bIsEffect[27])
				{
					for (int i = 25; i < 28; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[24])
				{
					m_bIsPlay[24] = false;
					m_bIsEffect[24] = IsEffect;
				}
				if (m_bIsEffect[24])
				{
					if (m_nframe[24] >= 10)
					{
						m_nframe[24] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[24]++;
						if (m_nAnimeNo[24] >= 30)
						{

							m_nAnimeNo[24] = 29;

							//m_bIsEffect[0] = false; 
							//m_bIsPlay[0] = true;
						}
					}
					m_pEffectMng[24]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[24], { m_pos[2].x, m_pos[2].y + 2.0f, m_pos[2].z + 1.0f }, 8);
					m_nframe[24]++;
				}
				break;
			case 2:	// ��
				if (m_bIsEffect[24] || m_bIsEffect[26] || m_bIsEffect[27])
				{
					m_bIsEffect[24] = false;
					m_bIsPlay[24] = true;
					m_nAnimeNo[24] = 0;

					for (int i = 24; i < 24; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}


				if (m_bIsPlay[25])
				{
					m_bIsPlay[25] = false;
					m_bIsEffect[25] = IsEffect;
				}
				if (m_bIsEffect[25])
				{
					if (m_nframe[25] >= 10)
					{
						m_nframe[25] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[25]++;
						if (m_nAnimeNo[25] >= 29)
						{
							m_nAnimeNo[25] = 28;

						}
					}
					m_pEffectMng[25]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[25], { m_pos[2].x, m_pos[2].y + 2.0f, m_pos[2].z - 1.0f }, 8);
					m_nframe[25]++;
				}
				break;
			case 3: // �E

				if (m_bIsEffect[24] || m_bIsEffect[25] || m_bIsEffect[27])
				{
					m_bIsEffect[27] = false;
					m_bIsPlay[27] = true;
					m_nAnimeNo[27] = 0;

					for (int i = 24; i < 26; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[26])
				{
					m_bIsPlay[26] = false;
					m_bIsEffect[26] = IsEffect;
				}
				if (m_bIsEffect[26])
				{
					if (m_nframe[26] >= 10)
					{
						m_nframe[26] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[26]++;
						if (m_nAnimeNo[26] >= 29)
						{
							m_nAnimeNo[26] = 28;
						}
					}
					m_pEffectMng[26]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[26], { m_pos[2].x + 2.0f, m_pos[2].y + 2.0f, m_pos[2].z - 0.5f }, 8);
					m_nframe[26]++;
				}
				break;
			case 4: // ��

				if (m_bIsEffect[24] || m_bIsEffect[25] || m_bIsEffect[26])
				{

					for (int i = 0; i < 3; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[27])
				{
					m_bIsPlay[27] = false;
					m_bIsEffect[27] = IsEffect;
				}
				if (m_bIsEffect[27])
				{
					if (m_nframe[27] >= 10)
					{
						m_nframe[27] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[27]++;
						if (m_nAnimeNo[27] >= 29)
						{
							m_nAnimeNo[27] = 28;
						}
					}
					m_pEffectMng[27]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[27], { m_pos[2].x - 2.0f, m_pos[2].y + 2.0f, m_pos[2].z - 0.5f }, 8);
					m_nframe[27]++;
				}
				break;
			default:
				break;
			}
			break;
		case 2:
			switch (Direction)
			{
			case 1:	// ��

				if (m_bIsEffect[29] || m_bIsEffect[30] || m_bIsEffect[31])
				{
					for (int i = 29; i < 32; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[28])
				{
					m_bIsPlay[28] = false;
					m_bIsEffect[28] = IsEffect;
				}
				if (m_bIsEffect[28])
				{
					if (m_nframe[28] >= 10)
					{
						m_nframe[28] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[28]++;
						if (m_nAnimeNo[28] >= 30)
						{
							m_nAnimeNo[28] = 29;
						}
					}
					m_pEffectMng[28]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[28], { m_pos[2].x, m_pos[2].y + 2.0f, m_pos[2].z + 1.0f }, 8);
					m_nframe[28]++;
				}
				break;
			case 2:	// ��

				if (m_bIsEffect[28] || m_bIsEffect[30] || m_bIsEffect[31])
				{
					m_bIsEffect[28] = false;
					m_bIsPlay[28] = true;
					m_nAnimeNo[28] = 0;

					for (int i = 28; i < 31; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[29])
				{
					m_bIsPlay[29] = false;
					m_bIsEffect[29] = IsEffect;
				}
				if (m_bIsEffect[29])
				{
					if (m_nframe[29] >= 10)
					{
						m_nframe[29] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[29]++;
						if (m_nAnimeNo[29] >= 29)
						{
							m_nAnimeNo[29] = 28;
						}
					}
					m_pEffectMng[29]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[29], { m_pos[2].x, m_pos[2].y + 2.0f, m_pos[2].z - 1.0f }, 8);
					m_nframe[29]++;
				}
				break;
			case 3: // �E

				if (m_bIsEffect[28] || m_bIsEffect[29] || m_bIsEffect[31])
				{
					m_bIsEffect[31] = false;
					m_bIsPlay[31] = true;
					m_nAnimeNo[31] = 0;

					for (int i = 28; i < 30; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}


				if (m_bIsPlay[30])
				{
					m_bIsPlay[30] = false;
					m_bIsEffect[30] = IsEffect;
				}
				if (m_bIsEffect[30])
				{
					if (m_nframe[30] >= 10)
					{
						m_nframe[30] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[30]++;
						if (m_nAnimeNo[30] >= 30)
						{
							m_nAnimeNo[30] = 30;
						}
					}
					m_pEffectMng[30]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[30], { m_pos[2].x + 2.0f, m_pos[2].y + 2.0f, m_pos[2].z - 0.5f }, 8);
					m_nframe[30]++;
				}
				break;
			case 4: // ��

				if (m_bIsEffect[28] || m_bIsEffect[29] || m_bIsEffect[30])
				{
					for (int i = 28; i < 31; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[31])
				{
					m_bIsPlay[31] = false;
					m_bIsEffect[31] = IsEffect;
				}
				if (m_bIsEffect[31])
				{
					if (m_nframe[31] >= 10)
					{
						m_nframe[31] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[31]++;
						if (m_nAnimeNo[31] >= 29)
						{
							m_nAnimeNo[31] = 28;
						}
					}
					m_pEffectMng[31]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[31], { m_pos[2].x - 2.0f, m_pos[2].y + 2.0f , m_pos[2].z - 0.5f }, 8);
					m_nframe[31]++;
				}
				break;
			default:
				break;
			}
			break;
		case 3:
			switch (Direction)
			{
			case 1:	// ��

				if (m_bIsEffect[33] || m_bIsEffect[34] || m_bIsEffect[35])
				{

					for (int i = 33; i < 36; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[32])
				{
					m_bIsPlay[32] = false;
					m_bIsEffect[32] = IsEffect;
				}
				if (m_bIsEffect[32])
				{
					if (m_nframe[32] >= 10)
					{
						m_nframe[32] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[32]++;
						if (m_nAnimeNo[32] >= 30)
						{
							m_nAnimeNo[32] = 29;
						}
					}
					m_pEffectMng[32]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[32], { m_pos[2].x, m_pos[2].y + 2.0f, m_pos[2].z + 1.0f }, 8);
					m_nframe[32]++;
				}
				break;
			case 2:	// ��
				if (m_bIsEffect[32] || m_bIsEffect[34] || m_bIsEffect[35])
				{
					m_bIsEffect[32] = false;
					m_bIsPlay[32] = true;
					m_nAnimeNo[32] = 0;

					for (int i = 32; i < 36; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[33])
				{
					m_bIsPlay[33] = false;
					m_bIsEffect[33] = IsEffect;
				}
				if (m_bIsEffect[33])
				{
					if (m_nframe[33] >= 10)
					{
						m_nframe[33] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[33]++;
						if (m_nAnimeNo[33] >= 29)
						{
							m_nAnimeNo[33] = 28;
						}
					}
					m_pEffectMng[33]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[33], { m_pos[2].x, m_pos[2].y + 2.0f, m_pos[2].z - 1.0f }, 8);
					m_nframe[33]++;
				}
				break;
			case 3: // �E

				if (m_bIsEffect[32] || m_bIsEffect[33] || m_bIsEffect[35])
				{
					m_bIsEffect[35] = false;
					m_bIsPlay[35] = true;
					m_nAnimeNo[35] = 0;

					for (int i = 8; i < 10; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[34])
				{
					m_bIsPlay[34] = false;
					m_bIsEffect[34] = IsEffect;
				}
				if (m_bIsEffect[34])
				{
					if (m_nframe[34] >= 10)
					{
						m_nframe[34] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[34]++;
						if (m_nAnimeNo[34] >= 30)
						{
							m_nAnimeNo[34] = 29;
						}
					}
					m_pEffectMng[34]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[34], { m_pos[2].x + 2.0f, m_pos[2].y + 2.0f, m_pos[2].z - 0.5f }, 8);
					m_nframe[34]++;
				}
				break;
			case 4: // ��

				if (m_bIsEffect[32] || m_bIsEffect[33] || m_bIsEffect[34])
				{

					for (int i = 32; i < 35; ++i)
					{
						m_bIsEffect[i] = false;
						m_bIsPlay[i] = true;
						m_nAnimeNo[i] = 0;
					}
				}

				if (m_bIsPlay[35])
				{
					m_bIsPlay[35] = false;
					m_bIsEffect[35] = IsEffect;
				}
				if (m_bIsEffect[35])
				{
					if (m_nframe[35] >= 10)
					{
						m_nframe[35] = 0;
						//�A�j���̃R�}��؂�ւ�
						m_nAnimeNo[35]++;
						if (m_nAnimeNo[35] >= 29)
						{
							m_nAnimeNo[35] = 28;
						}
					}
					m_pEffectMng[35]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[35], { m_pos[2].x - 2.0f, m_pos[2].y + 2.0f, m_pos[2].z - 0.5f }, 8);
					m_nframe[35]++;
				}
				break;
			default:
				break;
			}

		default:
			break;
		}
	}

}

void ArrowEffect::Draw(DirectX::XMFLOAT4X4 view, DirectX::XMFLOAT4X4 proj)
{
	if (m_bIsEffect[0])
	{
		m_pEffectMng[0]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[0], { m_pos[0].x, m_pos[0].y + 2.0f ,m_pos[0].z + 1.0f }, 8);
		m_pEffectMng[0]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[1])
	{
		m_pEffectMng[1]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[1], { m_pos[0].x, m_pos[0].y + 2.0f ,m_pos[0].z - 1.0f }, 8);
		m_pEffectMng[1]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[2])
	{
		m_pEffectMng[2]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[2], { m_pos[0].x + 2.0f, m_pos[0].y + 2.0f ,m_pos[0].z - 1.0f }, 8);
		m_pEffectMng[2]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[3])
	{
		m_pEffectMng[3]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[3], { m_pos[0].x - 2.0f, m_pos[0].y + 2.0f ,m_pos[0].z - 1.0f }, 8);
		m_pEffectMng[3]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[4])
	{
		m_pEffectMng[4]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[4], { m_pos[0].x, m_pos[0].y + 2.0f ,m_pos[0].z + 1.0f }, 8);
		m_pEffectMng[4]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[5])
	{
		m_pEffectMng[5]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[5], { m_pos[0].x, m_pos[0].y + 2.0f ,m_pos[0].z - 1.0f }, 8);
		m_pEffectMng[5]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[6])
	{
		m_pEffectMng[6]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[6], { m_pos[0].x + 2.0f, m_pos[0].y + 2.0f ,m_pos[0].z - 1.0f }, 8);
		m_pEffectMng[6]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[7])
	{
		m_pEffectMng[7]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[7], { m_pos[0].x - 2.0f, m_pos[0].y + 2.0f ,m_pos[0].z - 1.0f }, 8);
		m_pEffectMng[7]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[8])
	{
		m_pEffectMng[8]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[8], { m_pos[0].x, m_pos[0].y + 2.0f ,m_pos[0].z + 1.0f }, 8);
		m_pEffectMng[8]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[9])
	{
		m_pEffectMng[9]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[9], { m_pos[0].x, m_pos[0].y + 2.0f ,m_pos[0].z - 1.0f }, 8);
		m_pEffectMng[9]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[10])
	{
		m_pEffectMng[10]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[10], { m_pos[0].x + 2.0f, m_pos[0].y + 2.0f ,m_pos[0].z - 1.0f }, 8);
		m_pEffectMng[10]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[11])
	{
		m_pEffectMng[11]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[11], { m_pos[0].x - 2.0f, m_pos[0].y + 2.0f ,m_pos[0].z - 1.0f }, 8);
		m_pEffectMng[11]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[12])
	{
		m_pEffectMng[12]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[12], { m_pos[1].x, m_pos[1].y + 2.0f ,m_pos[1].z + 1.0f }, 8);
		m_pEffectMng[12]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[13])
	{
		m_pEffectMng[13]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[13], { m_pos[1].x, m_pos[1].y + 2.0f, m_pos[1].z - 2.0f }, 8);
		m_pEffectMng[13]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[14])
	{
		m_pEffectMng[14]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[14], { m_pos[1].x + 2.0f, m_pos[1].y + 2.0f ,m_pos[1].z - 0.75f }, 8);
		m_pEffectMng[14]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[15])
	{
		m_pEffectMng[15]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[15], { m_pos[1].x - 2.0f, m_pos[1].y + 2.0f ,m_pos[1].z - 0.75f }, 8);
		m_pEffectMng[15]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[16])
	{
		m_pEffectMng[16]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[16], { m_pos[1].x, m_pos[1].y + 2.0f ,m_pos[1].z + 1.0f }, 8);
		m_pEffectMng[16]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[17])
	{
		m_pEffectMng[17]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[17], { m_pos[1].x , m_pos[1].y + 2.0f ,m_pos[1].z - 2.0f }, 8);
		m_pEffectMng[17]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[18])
	{
		m_pEffectMng[18]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[18], { m_pos[1].x + 2.0f, m_pos[1].y + 2.0f ,m_pos[1].z - 0.75f }, 8);
		m_pEffectMng[18]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[19])
	{
		m_pEffectMng[19]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[19], { m_pos[1].x - 2.0f, m_pos[1].y + 2.0f ,m_pos[1].z - 0.75f }, 8);
		m_pEffectMng[19]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[20])
	{
		m_pEffectMng[20]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[20], { m_pos[1].x, m_pos[1].y + 2.0f ,m_pos[1].z + 1.0f }, 8);
		m_pEffectMng[20]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[21])
	{
		m_pEffectMng[21]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[21], { m_pos[1].x, m_pos[1].y + 2.0f ,m_pos[1].z - 1.0f }, 8);
		m_pEffectMng[21]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[22])
	{
		m_pEffectMng[22]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[22], { m_pos[1].x + 2.0f, m_pos[1].y + 2.0f ,m_pos[1].z - 0.75f }, 8);
		m_pEffectMng[22]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[23])
	{
		m_pEffectMng[23]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[23], { m_pos[1].x - 2.0f, m_pos[1].y + 2.0f ,m_pos[1].z - 0.75f }, 8);
		m_pEffectMng[23]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}

	if (m_bIsEffect[24])
	{
		m_pEffectMng[24]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[24], { m_pos[2].x , m_pos[2].y + 2.0f ,m_pos[2].z + 1.0f }, 8);
		m_pEffectMng[24]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[25])
	{
		m_pEffectMng[25]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[25], { m_pos[2].x, m_pos[2].y + 2.0f ,m_pos[2].z - 1.0f }, 8);
		m_pEffectMng[25]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[26])
	{
		m_pEffectMng[26]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[26], { m_pos[2].x + 2.0f, m_pos[2].y + 2.0f ,m_pos[2].z - 0.5f }, 8);
		m_pEffectMng[26]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[27])
	{
		m_pEffectMng[27]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[27], { m_pos[2].x - 2.0f, m_pos[2].y + 2.0f ,m_pos[2].z - 0.5f }, 8);
		m_pEffectMng[27]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[28])
	{
		m_pEffectMng[28]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[28], { m_pos[2].x , m_pos[2].y + 2.0f ,m_pos[2].z + 1.0f }, 8);
		m_pEffectMng[28]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[29])
	{
		m_pEffectMng[29]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[29], { m_pos[2].x, m_pos[2].y + 2.0f ,m_pos[2].z - 1.0f }, 8);
		m_pEffectMng[29]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[30])
	{
		m_pEffectMng[30]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[30], { m_pos[2].x + 2.0f, m_pos[2].y + 2.0f ,m_pos[2].z - 0.5f }, 8);
		m_pEffectMng[30]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[31])
	{
		m_pEffectMng[31]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[31], { m_pos[2].x - 2.0f, m_pos[2].y + 2.0f ,m_pos[2].z - 0.5f }, 8);
		m_pEffectMng[31]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[32])
	{
		m_pEffectMng[32]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[32], { m_pos[2].x, m_pos[2].y + 2.0f ,m_pos[2].z + 1.0f }, 8);
		m_pEffectMng[32]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[33])
	{
		m_pEffectMng[33]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[33], { m_pos[2].x, m_pos[2].y + 2.0f ,m_pos[2].z - 1.0f }, 8);
		m_pEffectMng[33]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[34])
	{
		m_pEffectMng[34]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[34], { m_pos[2].x + 2.0f, m_pos[2].y + 2.0f ,m_pos[2].z - 0.5f }, 8);
		m_pEffectMng[34]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
	if (m_bIsEffect[35])
	{
		m_pEffectMng[35]->Update({ 8.0f, 4.0f }, { 8.0f, 4.0f }, m_nAnimeNo[35], { m_pos[2].x - 2.0f, m_pos[2].y + 2.0f ,m_pos[2].z - 0.5f }, 8);
		m_pEffectMng[35]->Draw(view, proj, -90.0f, { 2.0f, 2.0f });
	}
}
