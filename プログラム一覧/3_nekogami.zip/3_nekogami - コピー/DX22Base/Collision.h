#ifndef ___COLLISION_H___
#define ___COLLISION_H___

// ==�C���N���[�h��==
#include <DirectXMath.h>

// ==�N���X==
class Collision
{
public:
	Collision();	
	~Collision();
	void Update();
	bool AABBCollision(DirectX::XMFLOAT3 CenterPos1, DirectX::XMFLOAT3 CenterPos2, DirectX::XMFLOAT3 Size1, DirectX::XMFLOAT3 Size2);

private:

};




#endif // !___COLLISION_H___

