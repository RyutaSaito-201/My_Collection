#ifndef __SELECT_CAMERA_H__
#define __SELECT_CAMERA_H__

#include "CameraBase.h"
#include "SelectPlayer.h"

class SelectCamera : public CameraBase
{
public:
	SelectCamera();
	~SelectCamera();
	void Update();
	
	void SetPlayer(SelectPlayer* player);
	DirectX::XMFLOAT2 GetCameraPos();

private:
	DirectX::XMFLOAT2 m_Camerapos;
	SelectPlayer* m_pSelectPlayer;


};





#endif // !__SELECT_CAMERA_H__

