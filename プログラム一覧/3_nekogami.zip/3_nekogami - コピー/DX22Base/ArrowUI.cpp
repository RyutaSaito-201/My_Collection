#include "ArrowUI.h"

ArrowUI::ArrowUI()
	: m_pos(0.0f, 0.0f, 0.0f)
{
	for (int i = 0; i < MAX_VECTOR; i++)
	{
		m_pTexture[i] = new Texture();
	}	// m_pPlayer->SetCamera(m_pCamera[CAM_DEBUG]);

	if (FAILED(m_pTexture[VECTOR_PHASE_1]->Create("Assets/Texture/phase1_Arrow.png")))
	{
		MessageBox(NULL, "mark_arrow_up.png", "Error", MB_OK);
	}
	if (FAILED(m_pTexture[VECTOR_PHASE_2]->Create("Assets/Texture/phase2_Arrow.png")))
	{
		MessageBox(NULL, "mark_arrow_down.png", "Error", MB_OK);
	}
	if (FAILED(m_pTexture[VECTOR_PHASE_3]->Create("Assets/Texture/phase3_Arrow.png")))
	{
		MessageBox(NULL, "mark_arrow_right.png", "Error", MB_OK);
	}

	// ���\���p�̃J�����̐���
	m_pCamera = new CameraDebug();

	// �J�������W�̐ݒ�
	m_pCamera->SetPos(0.0f, 12.0f, -5.0f);
	m_pCamera->Setlook(0.0f, 0.0f, 0.0f);
	m_pCamera->SetUp(0.0f, 0.0f, 1.0f);

}

ArrowUI::~ArrowUI()
{
	for (int i = 0; i < MAX_VECTOR; i++)
	{
		if (m_pTexture[i])
		{
			delete m_pTexture[i];
			m_pTexture[i] = nullptr;
		}
	}

	if (m_pCamera)
	{
		delete m_pCamera;
		m_pCamera = nullptr;
	}
}

tuple <DirectX::XMFLOAT4, DirectX::XMFLOAT2> ArrowUI::Update(int VectorSel, DirectX::XMFLOAT3 Pos, DirectX::XMFLOAT3 Size)
{

	DirectX::XMFLOAT4 mat;
	DirectX::XMFLOAT2 size;


	if (Size.y < Size.x)
	{
		if (VectorSel == VECTOR_UP) { Pos.z += Size.z / 4; }
		if (VectorSel == VECTOR_DOWN) { Pos.z -= Size.z / 4; }
		if (VectorSel == VECTOR_RIGHT) { Pos.x += Size.x / 2; }
		if (VectorSel == VECTOR_LEFT) { Pos.x -= Size.x / 2; }
	}
	else
	{
		if (VectorSel == VECTOR_UP) { Pos.z += Size.z / 4; }
		if (VectorSel == VECTOR_DOWN) { Pos.z -= Size.z / 4; }
		if (VectorSel == VECTOR_RIGHT) { Pos.x += Size.x / 4; }
		if (VectorSel == VECTOR_LEFT) { Pos.x += Size.x / 4; }
	}
	switch (VectorSel)
	{
	case VECTOR_UP:
		mat.x = Pos.x;
		mat.y = Pos.y;
		mat.z = Pos.z;
		mat.w = (float)VectorSel;
		size.x = 0.1f;
		size.y = 0.1f;
		return std::forward_as_tuple(mat, size);
		break;
	case VECTOR_DOWN:
		mat.x = Pos.x;
		mat.y = Pos.y;
		mat.z = Pos.z;
		mat.w = (float)VectorSel;
		size.x = 0.1f;
		size.y = 0.1f;
		return std::forward_as_tuple(mat, size);
		break;
	case VECTOR_RIGHT:
		mat.x = Pos.x;
		mat.y = Pos.y;
		mat.z = Pos.z;
		mat.w = (float)VectorSel;
		size.x = 0.1f;
		size.y = 0.1f;
		return std::forward_as_tuple(mat, size);
		break;
	case VECTOR_LEFT:
		mat.x = Pos.x;
		mat.y = Pos.y;
		mat.z = Pos.z;
		mat.w = (float)VectorSel;
		size.x = 0.1f;
		size.y = 0.1f;
		return std::forward_as_tuple(mat, size);
		break;
	}

}

// ���P�_
// �E�����������Ɖ������{�b�N�X�̍��W���擾���ĕ������������{�b�N�X�̃x�N�g���̈ʒu�ɕ\������
//	������ǉ�
void ArrowUI::Draw(int NowPhase, DirectX::XMFLOAT4 Pos, DirectX::XMFLOAT2 Size, CameraBase* m_pCamera)
{

	switch ((int)Pos.w)
	{
	case VECTOR_UP:
		SetDrawArrow(Pos, 0.0f, Size, NowPhase, m_pCamera);
		break;
	case VECTOR_DOWN:
		SetDrawArrow(Pos, 34.60f, Size, NowPhase, m_pCamera);
		break;
	case VECTOR_RIGHT:
		SetDrawArrow(Pos, 14.1f, Size, NowPhase, m_pCamera);
		break;
	case VECTOR_LEFT:
		SetDrawArrow(Pos, 4.9f, Size, NowPhase, m_pCamera);
		break;
	}
}

void ArrowUI::SetDrawArrow(DirectX::XMFLOAT4 Pos, float RotY, DirectX::XMFLOAT2 size, int TextureSelect, CameraBase* _m_pCamera)
{

	// ���[���h�s���X��Y�݂̂��l�����č쐬
	DirectX::XMMATRIX mat =
		DirectX::XMMatrixScaling(1.0f, 1.0f, 1.0f)*
		DirectX::XMMatrixRotationX(5.0f) * DirectX::XMMatrixRotationY(RotY) * DirectX::XMMatrixRotationZ(0.0f) *
		DirectX::XMMatrixTranslation(Pos.x, Pos.y + 1.0f, Pos.z);
	DirectX::XMFLOAT4X4 world;
	DirectX::XMStoreFloat4x4(&world, DirectX::XMMatrixTranspose(mat));
	Sprite::SetWorld(world);
	Sprite::SetView(m_pCamera->GetViewMatrix());
	Sprite::SetProjection(m_pCamera->GetProjyectionMatrix());

	// ���̑傫�����摜UV�̕ω��ŕ\��
	if (size.y <= 1.0f)
	{
		//Sprite::SetUVPos(DirectX::XMFLOAT2(1.0f, size.y / 1.5f));
		Sprite::SetUVScale(DirectX::XMFLOAT2(1.0f, size.y));
	}
	else
	{
		//Sprite::SetUVPos(DirectX::XMFLOAT2(1.0f, 1.0f));
		Sprite::SetUVScale(DirectX::XMFLOAT2(1.0f, 1.0f));
	}

	//Sprite::SetOffset(DirectX::XMFLOAT2(0.0f, -size.y));

	Sprite::SetSize(DirectX::XMFLOAT2(1.0f, -1.0f));
	Sprite::SetTexture(m_pTexture[TextureSelect]);
	Sprite::Draw();
}
