#ifndef __CAMERA_SELECT_H__
#define __CAMERA_SELECT_H__

#include "CameraSelectBase.h"
//#include "SelectPlayer.h"

class CameraSelect 
	:public CameraSB
{
public:
	CameraSelect();
	~CameraSelect();
	void Update();

private:
	//SelectPlayer* m_pSPlayer;


};



#endif // !__CAMERA_SELECT_H__

