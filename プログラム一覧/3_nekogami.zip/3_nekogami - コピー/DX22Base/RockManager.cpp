#include "RockManager.h"

CRockManager::CRockManager()
	: m_CameraPos(-6.0f, 3.0f, -5.0f)
	, m_CameraLook(-6.0f, 0.0f, 0.0f)
{
	m_pModel = new Model();
	if (!m_pModel->Load("Assets/Model/Rock/Rock.fbx", 1.0f, Model::XFlip))
	{
		MessageBox(NULL, "Rock", "Error", MB_OK);
	}

	//���_�V�F�[�_�[��ǂݍ���Ń��f���ɐݒ�
	m_pVS = new VertexShader();
	if (FAILED(m_pVS->Load("Assets/Shader/VS_Model.cso")))
	{
		MessageBox(nullptr, "VS_Model.cso", "Error", MB_OK);
	}
	m_pModel->SetVertexShader(m_pVS);	//���f���֓ǂݍ��񂾒��_�V�F�[�_�[��ݒ�

	m_pCamera = new CameraDebug();
}

void CRockManager::CreateRock(float ScalingX, float ScalingY, float ScalingZ, float posX, float posY, float posZ)
{
	m_Size.x = ScalingX;
	m_Size.y = ScalingY;
	m_Size.z = ScalingZ;
	m_pos.x = posX;
	m_pos.y = posY;
	m_pos.z = posZ;
}

void CRockManager::Draw(DirectX::XMFLOAT4X4 mat[3])
{
	// �J�����̃A�b�v�f�[�g
	m_CameraPos.x += 6.0f / 60.0f;
	m_CameraPos.y += 9.0f / 60.0f;
	m_CameraLook.x += 6.0f / 60.0f;
	m_CameraLook.y -= 0.3f / 60.0f;
	if (m_CameraLook.x <= 0.0f)
	{
		m_pCamera->SetPos(m_CameraPos.x, m_CameraPos.y, -5.0f);
		m_pCamera->Setlook(m_CameraLook.x, m_CameraLook.y, 0.0f);
	}

	m_OldPos = m_pos;

	DirectX::XMMATRIX world;
	//--- Geometory�p�̕ϊ��s����v�Z
	world =
		DirectX::XMMatrixScaling(m_Size.x, m_Size.y, m_Size.z)*
		DirectX::XMMatrixRotationX(0.0f) * DirectX::XMMatrixRotationY(0.0f) * DirectX::XMMatrixRotationZ(0.0f) *
		DirectX::XMMatrixTranslation(m_pos.x, m_pos.y, m_pos.z);
	world = DirectX::XMMatrixTranspose(world);	// �]�ڍs��ɕϊ�
	DirectX::XMStoreFloat4x4(&mat[0], world);	// XMMATRIX�^����XMFLOAT4x4�^(mat[0])�֕ϊ����Ċi�[
	mat[1] = m_pCamera->GetViewMatrix();
	mat[2] = m_pCamera->GetProjyectionMatrix();

	// �s����V�F�[�_�[�֐ݒ�
	m_pVS->WriteBuffer(0, mat);

	//--- Geometory�p�̕ϊ��s���ݒ�
	Geometory::SetWorld(mat[0]);
	Geometory::SetView(mat[1]);
	Geometory::SetProjection(mat[2]);

	if (m_pModel)
	{
		m_pModel->Draw();
	}
	//Geometory::DrawBox();
}

void CRockManager::SetPos(DirectX::XMFLOAT3 rockpos)
{
	m_pos.x += rockpos.x;
	m_pos.y += rockpos.y;
	m_pos.z += rockpos.z;
}

void CRockManager::SetOldPos(DirectX::XMFLOAT3 oldpos)
{
	m_pos = m_OldPos;
}

void CRockManager::SetDirection(int nDirection, int i)
{
	m_nDirection[i] = nDirection;
}

int CRockManager::GetDirection(int i)
{
	return m_nDirection[i];
}

DirectX::XMFLOAT3 CRockManager::GetPos()
{
	return m_pos;
}

DirectX::XMFLOAT3 CRockManager::GetOldPos()
{
	return m_OldPos;
}

DirectX::XMFLOAT3 CRockManager::GetSize()
{
	return m_Size;
}

DirectX::XMFLOAT3 CRockManager::GetSizetoRock()
{
	m_CollSize.x = m_Size.x * 1.2f;
	m_CollSize.y = m_Size.y;
	m_CollSize.z = m_Size.z * 1.2f;
	return m_CollSize;
}
