#ifndef __SCENE_SELECT_H__
#define __SCENE_SELECT_H__

#include "Input.h"
#include "Model.h"
#include "Geometory.h"
#include "Shader.h"
#include "Texture.h"
#include "Sprite.h"
#include "SelectPlayer.h"
#include "SceneManager.h"
//#include "CameraDebug.h"
#include "CameraSelect.h"
#include "Sound.h"

#define MAX_GATE (5)

class SceneSelect
{
public:
	SceneSelect();
	~SceneSelect();
	void Update(SceneManager* pManager);
	void Draw();

	void DrawBack();
	void DrawTileModel();
	void DrawGateModel(int num);
	void DrawKey(int num);
	void DrawDoorModel();
	bool DistanceDraw(DirectX::XMFLOAT3 posA, DirectX::XMFLOAT3 posB);
	bool EntryCollision(DirectX::XMFLOAT3 Playerpos, DirectX::XMFLOAT2 PlayerSize, DirectX::XMFLOAT3 ObjectPos);
	static int GetStaticStageNo();
	DirectX::XMFLOAT3 GetStagePos();

private:
	VertexShader* m_pVS;
	Texture* m_pTexture;
	Texture* m_KeyTexture;
	//Texture* m_pGateTexture;
	Model* m_pDoorModel;
	Model* m_pGateModel;
	Model* m_pTileModel;
	SelectPlayer* m_pPlayer;
	CameraSelect* m_pCamera;

	XAUDIO2_BUFFER* m_pBGM;
	IXAudio2SourceVoice* m_pBGMSpeaker;

	DirectX::XMFLOAT4 m_alpha;
	DirectX::XMFLOAT2 m_Playerpos;
	DirectX::XMFLOAT3 m_Backpos;
	DirectX::XMFLOAT3 m_Gatepos[MAX_GATE];
	DirectX::XMFLOAT2 m_UVPos;
	DirectX::XMFLOAT2 m_UVScale;
	static int StageNo;

	bool m_bStartBGM;
};

#endif // !__SCENE_SELECT_H__

