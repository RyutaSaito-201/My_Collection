#include "ItemUI.h"
#include "Input.h"

//���Ԃ̃e�N�X�`��X,Y���W
#define TIME_UI_POSX (690.0f) 
#define TIME_UI_POSY (60.0f)

//���Ԃ̃e�N�X�`���T�C�Y
#define TIME_UI_SIZEX (1250.0f)
#define TIME_UI_SIZEY (-100.0f) 

//���Ԓ�~���̎��ԃo�[�e�N�X�`����X,Y���W
#define CLOCK_UI_POSX (687.0f)
#define CLOCK_UI_POSY (60.0f)

//���Ԓ�~���̎��ԃo�[�e�N�X�`���̃T�C�Y
#define CLOCK_UI_SIZEX (1050.0f)
#define CLOCK_UI_SIZEY (-20.0f)

//�N���A�摜�̃e�N�X�`����X,Y���W
#define CLEAR_UI_POSX (640.0f)
#define CLEAR_UI_POSY (360.0f)

//�N���A��ʂ̃e�N�X�`���T�C�Y
#define CLEAR_UI_SIZEX (1000.0f)
#define CLEAR_UI_SIZEY (-200.0f)

//�ǂݍ��݃t�@�C��
#define FILE_NAME ("Assets/Texture/TimeBar.png")
#define FILE_NAME2 ("Assets/Texture/TimeStopBar.png")
#define FILE_NAME3 ("Assets/Texture/TimeStopBar2.png")
#define FILE_NAME4 ("Assets/Texture/TimeStopBar3.png")
#define FILE_NAME5 ("Assets/Texture/CLEAR.png")

#define MAX_TEXTURE (5)

int i;

ItemUI::ItemUI()
	: m_UIAlpha(1.0f, 1.0f, 1.0f, 1.0f)
	, m_ClrUIAlpha(1.0f, 1.0f, 1.0f, 0.0f)
	, m_Alpha(0.0f)
{
	for (i = 0; i < MAX_TEXTURE; i++)
	{
		m_pTexture[i] = new Texture();
	}

	if (FAILED(m_pTexture[0]->Create(FILE_NAME)))
	{
		MessageBox(NULL, "ItemUI TimeBar.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[1]->Create(FILE_NAME2)))
	{
		MessageBox(NULL, "ItemUI TimeStopBar.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[2]->Create(FILE_NAME3)))
	{
		MessageBox(NULL, "ItemUI TimeStopBar2.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[3]->Create(FILE_NAME4)))
	{
		MessageBox(NULL, "ItemUI TimeStopBar3.png", "Error", MB_OK);
	}

	if (FAILED(m_pTexture[4]->Create(FILE_NAME5)))
	{
		MessageBox(NULL, "CLEAR.png", "Error", MB_OK);
	}
}

ItemUI::~ItemUI()
{
	for (i = 0; i < MAX_TEXTURE; i++)
	{
		if (m_pTexture[i])
		{
			delete m_pTexture[i];
			m_pTexture[i] = nullptr;
		}
	}
	
}

void ItemUI::Update()
{

}
//�ʏ펞�̃^�C���o�[�e�N�X�`����\��
void ItemUI::DrawUI()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			TIME_UI_POSX, TIME_UI_POSY, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(TIME_UI_SIZEX, TIME_UI_SIZEY));
	Sprite::SetTexture(m_pTexture[0]);
	Sprite::Draw();
}

//�������牺�͎��~�ߒ��̃o�[�\��
//�ԁA���F�A�ΐF�S�ĕ\��
void ItemUI::DrawStopTime()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			CLOCK_UI_POSX, CLOCK_UI_POSY, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(CLOCK_UI_SIZEX, CLOCK_UI_SIZEY));
	Sprite::SetTexture(m_pTexture[1]);
	Sprite::Draw();
}

//�ԁA���F��\��
void ItemUI::DrawStopTime2()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			CLOCK_UI_POSX, CLOCK_UI_POSY, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(CLOCK_UI_SIZEX, CLOCK_UI_SIZEY));
	Sprite::SetTexture(m_pTexture[2]);
	Sprite::Draw();
}

//�Ԃ̂ݕ\��
void ItemUI::DrawStopTime3()
{
	DirectX::XMFLOAT4X4 mat[3];

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			CLOCK_UI_POSX, CLOCK_UI_POSY, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_UIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(CLOCK_UI_SIZEX, CLOCK_UI_SIZEY));
	Sprite::SetTexture(m_pTexture[3]);
	Sprite::Draw();
}

void ItemUI::DrawClear()
{
	DirectX::XMFLOAT4X4 mat[3];

	if (m_Alpha <= 1.0f) { m_Alpha += 1.0f / 60.0f; }
	m_ClrUIAlpha.w = m_Alpha;

	//�e�N�X�`���̈ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			CLEAR_UI_POSX, CLEAR_UI_POSY, 0.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ 1.0f, 1.0f });
	Sprite::SetUVPos({ 1.0f, 1.0f });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_ClrUIAlpha);
	Sprite::SetSize(DirectX::XMFLOAT2(CLEAR_UI_SIZEX, CLEAR_UI_SIZEY));
	Sprite::SetTexture(m_pTexture[4]);
	Sprite::Draw();
}