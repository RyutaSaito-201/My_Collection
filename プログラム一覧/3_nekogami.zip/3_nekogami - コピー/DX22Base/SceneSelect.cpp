#include "SceneSelect.h"
#include <Xinput.h>
#define MAX_TEXTURE (2)
#define MAX_MODEL (1)
#define DRAW_RANGE (750.0f)

// ==�O���[�o���ϐ�==
XINPUT_STATE selectstate;
//�ÓI�ϐ�(static)�̏�����
int SceneSelect::StageNo = 0;

SceneSelect::SceneSelect()
	:m_alpha(1.0f, 1.0f, 1.0f, 1.0f)
	, m_Backpos(2340.0f, 360.0f, 0.0f)
	, m_UVPos(1.0f, 1.0f)
	, m_UVScale(1.0f, 1.0f)
	, m_bStartBGM(false)
	, m_pBGM(nullptr)
	, m_pBGMSpeaker(nullptr)
{

	DWORD dwResult;
	ZeroMemory(&selectstate, sizeof(XINPUT_STATE));

	// �ڑ�����Ă��邩��ϐ��Ɋi�[
	dwResult = XInputGetState(0, &selectstate);

	if (!(dwResult == ERROR_SUCCESS))
	{
		// �R���g���[���[���ڑ�����Ă��Ȃ�
		MessageBox(NULL, "Not Connect", "Controller", MB_OK);
	}


	m_Gatepos[0] = { 1200.0f, 620.0f, 0.0f };
	m_Gatepos[1] = { 1700.0f, 620.0f, 0.0f };
	m_Gatepos[2] = { 2200.0f, 620.0f, 0.0f };
	m_Gatepos[3] = { 2700.0f, 620.0f, 0.0f };
	m_Gatepos[4] = { 3200.0f, 620.0f, 0.0f };


	//--���f���̓ǂݍ���
	//�^�C���̃��f���ǂݍ���
	//m_pTileModel = new Model();
	//if (!m_pTileModel->Load("Assets/Model/Tile/ground.fbx", 0.065f, Model::XFlip));
	//{
	//	MessageBox(NULL, "Tile", "Error", MB_OK);
	//}

	//---�X�e�[�W�Q�[�g�̃��f���ǂݍ���---
	m_pGateModel = new Model();

	if (!m_pGateModel->Load("Assets/Model/Gate/gate.fbx", 0.3f, Model::XFlip))
	{
		MessageBox(NULL, "Gate", "Error", MB_OK);
	}

	//---�h�A���f���̓ǂݍ���---
	m_pDoorModel = new Model();
	if (!m_pDoorModel->Load("Assets/Model/GateDoor/01.fbx", 0.5f, Model::XFlip))
	{
		MessageBox(NULL, "Door", "Error", MB_OK);
	}


	//���_�V�F�[�_�[��ǂݍ���Ń��f���Ɋi�[
	m_pVS = new VertexShader();
	if (FAILED(m_pVS->Load("Assets/Shader/VS_Model.cso")))
	{
		MessageBox(nullptr, "VS_Model.cso", "Error", MB_OK);
	}
	//m_pTileModel->SetVertexShader(m_pVS);	//���f���֓ǂݍ��񂾒��_�V�F�[�_�[��ݒ�
	m_pGateModel->SetVertexShader(m_pVS);
	m_pDoorModel->SetVertexShader(m_pVS);

	//�w�i�e�N�X�`���̓ǂݍ���
	m_pTexture = new Texture();
	if (FAILED(m_pTexture->Create("Assets/Texture/satgehaikei.png")))
	{
		MessageBox(NULL, "SceneSelect.back", "Error", MB_OK);
	}

	//�L�[���S�̃e�N�X�`���̓ǂݍ���
	m_KeyTexture = new Texture();
	if (FAILED(m_KeyTexture->Create("Assets/Texture/letter-a.png")))
	{
		MessageBox(NULL, "Select.Key", "Error", MB_OK);
	}


	//�v���C���[�̐���
	m_pPlayer = new SelectPlayer();

	//�J�����̐���
	m_pCamera = new CameraSelect();

	//���f�[�^�ǂݍ���
	m_pBGM = LoadSound("Assets/Sound/Select.wav", true);

}

SceneSelect::~SceneSelect()
{

	if (m_pDoorModel)
	{
		delete m_pDoorModel;
		m_pDoorModel = nullptr;
	}

	if (m_pGateModel)
	{
		delete m_pGateModel;
		m_pGateModel = nullptr;
	}

	if (m_pVS)
	{
		delete m_pVS;
		m_pVS = nullptr;
	}

	if (m_pTexture)
	{
		delete m_pTexture;
		m_pTexture = nullptr;
	}

	if (m_KeyTexture)
	{
		delete m_KeyTexture;
		m_KeyTexture = nullptr;
	}

	if (m_pPlayer)
	{
		delete m_pPlayer;
		m_pPlayer = nullptr;
	}

	if (m_pCamera)
	{
		delete m_pCamera;
		m_pCamera = nullptr;
	}

	//if (m_pTileModel)
	//{
	//	delete m_pTileModel;
	//	m_pTileModel = nullptr;
	//}
}

void SceneSelect::Update(SceneManager* pManager)
{
	XInputGetState(0, &selectstate);

	//BGM�Đ�
	if (!m_bStartBGM)
	{
		m_pBGMSpeaker = PlaySound(m_pBGM);
		m_pBGMSpeaker->SetVolume(0.5f);		//�{�����[������
		m_bStartBGM = true;
	}

	if ((selectstate.Gamepad.sThumbLX < -XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE)
		|| (selectstate.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT)
		|| (IsKeyPress('A')))
	{
		if (m_Backpos.x <= 2340.0f)
		{
			//�����ŃQ�[�g�Ȃǂ̍��W���v�Z���ē�����
			m_Backpos.x += 5.0f;

			for (int i = 0; i < MAX_GATE; i++)
			{
				m_Gatepos[i].x += 5.0f;

			}

		}
	}

	if ((selectstate.Gamepad.sThumbLX > XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE)
		|| (selectstate.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT)
		|| (IsKeyPress('D')))
	{
		if (m_Backpos.x >= -1060.0f)
		{
			m_Backpos.x -= 5.0f;

			for (int i = 0; i < MAX_GATE; i++)
			{
				m_Gatepos[i].x -= 5.0f;

			}

		}

	}

	for (int i = 0; i < MAX_GATE; i++)
	{
		if (EntryCollision(m_pPlayer->GetPos(), m_pPlayer->GetSize(), m_Gatepos[i]))
		{
			if (IsKeyPress('W') || (selectstate.Gamepad.wButtons & XINPUT_GAMEPAD_A))
			{
				StageNo = i;

				//�V�[���J�ڂ̏���
				pManager->SetNextScene(SCENE_GAME);
				m_pBGMSpeaker->Stop();	//���̍Đ����~
			}
		}
	}

	//m_pPlayer->Update();
	//m_pCamera->Update();

}

void SceneSelect::Draw()
{
	RenderTarget* pRTV = GetDefaultRTV();
	DepthStencil* pDSV = GetDefaultDSV();

	//�[�x�o�b�t�@�𖳌��ɂ���(2D�\��)
	SetRenderTargets(1, &pRTV, nullptr);

	DrawBack();
	for (int i = 0; i < MAX_GATE; i++)
	{
		if (DistanceDraw(m_pPlayer->GetPos(), m_Gatepos[i]))
		{
			DrawGateModel(i);
			DrawDoorModel();

			if (EntryCollision(m_pPlayer->GetPos(), m_pPlayer->GetSize(), m_Gatepos[i]))
			{
				DrawKey(i);
			}

		}
	}

	m_pPlayer->Draw();


	//�[�x�o�b�t�@��L���ɂ���(3D�\��)
	SetRenderTargets(1, &pRTV, pDSV);
	//DrawGateModel();
	//DrawTileModel();

}

//--�w�i�̕`��֐�--
void SceneSelect::DrawBack()
{
	//-- �w�i�`��
	DirectX::XMFLOAT4X4 mat[3];
	//�e�N�X�`���̕`��ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			m_Backpos.x, m_Backpos.y, m_Backpos.z
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ m_UVScale.x, m_UVScale.y });
	Sprite::SetUVPos({ m_UVPos.x, m_UVPos.y });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_alpha);
	Sprite::SetSize(DirectX::XMFLOAT2(4680.0f, -720.0f));	//1280.-720
	Sprite::SetTexture(m_pTexture);
	Sprite::Draw();


}

//--�^�C�����f���\���̊֐�--
void SceneSelect::DrawTileModel()
{
	DirectX::XMFLOAT4X4 mat[3];
	DirectX::XMMATRIX world =
		DirectX::XMMatrixScaling(1.0f, 1.0f, 1.0f)* DirectX::XMMatrixTranslation(100.0f, 100.0f, 0.0f);

	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));
	mat[1] = m_pCamera->GetViewMatrix();
	mat[2] = m_pCamera->GetProjyectionMatrix();

	// �s����V�F�[�_�[�֐ݒ�
	m_pVS->WriteBuffer(0, mat);

	//--- Geometory�p�̕ϊ��s���ݒ�
	Geometory::SetWorld(mat[0]);
	Geometory::SetView(mat[1]);
	Geometory::SetProjection(mat[2]);

	if (m_pTileModel)
	{
		m_pTileModel->Draw();
	}


}

//--�Q�[�g���f���\���̊֐�--
void SceneSelect::DrawGateModel(int num)
{
	DirectX::XMFLOAT4X4 mat[3];
	//DirectX::XMMATRIX world =
	//	DirectX::XMMatrixScaling(100.0f, 100.0f, 100.0f)*
	//	DirectX::XMMatrixRotationX(3.141592f * 0.5f)
	//	* DirectX::XMMatrixTranslation(-5.50f, 0.0f, 0.0f);

	//DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));
	//mat[1] = m_pCamera->GetViewMatrix();
	//mat[2] = m_pCamera->GetProjyectionMatrix();


	DirectX::XMMATRIX world =
		DirectX::XMMatrixScaling(1000.0f, 1000.0f, 1000.0f) *
		DirectX::XMMatrixRotationX(3.141592f * 0.5f) *
		DirectX::XMMatrixTranslation(
			m_Gatepos[num].x, m_Gatepos[num].y, m_Gatepos[num].z
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));



	// �s����V�F�[�_�[�֐ݒ�
	m_pVS->WriteBuffer(0, mat);

	if (m_pGateModel)
	{
		m_pGateModel->Draw();
	}

	////-- �Q�[�g�`��
	//DirectX::XMFLOAT4X4 mat[3];
	////�e�N�X�`���̕`��ʒu
	//DirectX::XMMATRIX world =
	//	DirectX::XMMatrixTranslation(
	//		m_Gatepos.x, m_Gatepos.y, m_Gatepos.z
	//	);
	//DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	//DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	//DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
	//	0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	//);
	//DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	//Sprite::SetWorld(mat[0]);
	//Sprite::SetView(mat[1]);
	//Sprite::SetProjection(mat[2]);
	//Sprite::SetColor(m_alpha);
	//Sprite::SetSize(DirectX::XMFLOAT2(400.0f, -400.0f));	//1280.-720
	//Sprite::SetTexture(m_pGateTexture);
	//Sprite::Draw();

}

void SceneSelect::DrawKey(int num)
{
	DirectX::XMFLOAT4X4 mat[3];
	//�e�N�X�`���̕`��ʒu
	DirectX::XMMATRIX world =
		DirectX::XMMatrixTranslation(
			m_Gatepos[num].x, m_Gatepos[num].y - 200.0f, m_Gatepos[num].z
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	Sprite::SetUVScale({ m_UVScale.x, m_UVScale.y });
	Sprite::SetUVPos({ m_UVPos.x, m_UVPos.y });
	Sprite::SetWorld(mat[0]);
	Sprite::SetView(mat[1]);
	Sprite::SetProjection(mat[2]);
	Sprite::SetColor(m_alpha);
	Sprite::SetSize(DirectX::XMFLOAT2(100.0f, -100.0f));	//1280.-720
	Sprite::SetTexture(m_KeyTexture);
	Sprite::Draw();


}


//--�h�A�̃��f����\������֐�--
void SceneSelect::DrawDoorModel()
{
	DirectX::XMFLOAT4X4 mat[3];
	DirectX::XMMATRIX world =
		DirectX::XMMatrixScaling(650.0f, 2000.0f, 1000.0f) *
		DirectX::XMMatrixRotationX(3.141592f * 0.6f) *
		DirectX::XMMatrixTranslation(
			m_Gatepos[0].x, m_Gatepos[0].y, 1.0f
		);
	DirectX::XMStoreFloat4x4(&mat[0], DirectX::XMMatrixTranspose(world));

	DirectX::XMStoreFloat4x4(&mat[1], DirectX::XMMatrixIdentity());

	DirectX::XMMATRIX proj = DirectX::XMMatrixOrthographicOffCenterLH(
		0.0f, 1280.0f, 720.0f, 0.0f, 0.1f, 10.0f
	);
	DirectX::XMStoreFloat4x4(&mat[2], DirectX::XMMatrixTranspose(proj));

	// �s����V�F�[�_�[�֐ݒ�
	m_pVS->WriteBuffer(0, mat);

	if (m_pDoorModel)
	{
		m_pDoorModel->Draw();
	}


}



//��苗���ɍs���ƕ`�悷��֐�
bool SceneSelect::DistanceDraw(DirectX::XMFLOAT3 posA, DirectX::XMFLOAT3 posB)
{
	float distance;
	distance = posA.x - posB.x;
	distance = fabs(distance);

	if (distance < DRAW_RANGE)
	{
		return true;
	}

	return false;
}

//�I�u�W�F�N�g�̍��W�ƁA�v���C���[�Ƃ̓����蔻����Ƃ�֐�
bool SceneSelect::EntryCollision(DirectX::XMFLOAT3 Playerpos, DirectX::XMFLOAT2 PlayerSize, DirectX::XMFLOAT3 ObjectPos)
{
	float halfWidth = PlayerSize.x / 2;
	float rightside = Playerpos.x + halfWidth;
	float leftside = Playerpos.x - halfWidth;

	if (rightside > ObjectPos.x && leftside < ObjectPos.x)
	{
		return true;
	}


	return false;
}

int SceneSelect::GetStaticStageNo()
{
	return StageNo;
}

DirectX::XMFLOAT3 SceneSelect::GetStagePos()
{
	return m_Gatepos[StageNo];
}

